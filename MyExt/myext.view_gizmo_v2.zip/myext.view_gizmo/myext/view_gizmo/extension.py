"""ビューポート左上にワールド軸（X/Y/Z）の向きを表示する。

見た目:
- 各軸の先端に円盤（ボール）を置く。正方向のボールには X/Y/Z の文字を入れ、
  負方向のボールは暗い塗りと軸色の輪郭線で描く。
- 中心から正方向のボールへ太い軸線を引く。
- 背景に半透明の暗い円盤を敷いて、明るいシーンでも軸色が沈まないようにする。

設計上の要点:
- SceneView には gesture を一切付けない。omni.ui の Widget はコールバックを
  持たない限りマウスイベントを消費しないため、Gizmo の上でもビューポートの
  カメラ操作はそのまま通る。
- ホットキーは登録しない。ON/OFF は MyExt メニューのチェック項目のみ。
- omni.ui.scene は生成順に描画する。重なり順を毎フレーム変えるため、
  ボールを6個のスロットとして固定順で生成し、奥行きでソートした結果を
  スロットへ割り当て直す（奥のボールを先に描く）。
"""

import asyncio

import carb.settings
import omni.ext
import omni.kit.app
import omni.kit.menu.utils as menu_utils
import omni.ui as ui
from omni.kit.menu.utils import MenuItemDescription
from omni.kit.viewport.utility import get_active_viewport_window
from omni.ui import scene as sc
from pxr import Gf

MENU_GROUP = "MyExt"
MENU_ITEM_NAME = "View Gizmo"
SETTING_ENABLED = "/exts/myext.view_gizmo/enabled"

# 配置とサイズ（ピクセル）
GIZMO_SIZE_PX = 128
MARGIN_LEFT_PX = 12
MARGIN_TOP_PX = 40  # ビューポート上端のメニューバーと重ねないための余白

# SceneView のローカル座標は [-1, 1]。以下はその比率で指定する
BACKDROP_RADIUS = 0.97
ORBIT_RADIUS = 0.70  # 中心からボール中心までの距離
BALL_RADIUS = 0.21
AXIS_LINE_THICKNESS = 4.0
RING_THICKNESS = 2.0
BALL_TESSELATION = 48
LABEL_SIZE = 13

AXIS_LABELS = ("X", "Y", "Z")

# omni.ui の色は 0xAABBGGRR
COLOR_TRANSPARENT = 0x00000000
COLOR_BACKDROP = 0x59141414
COLOR_BALL_TEXT = 0xFF1A1A1A
# 正方向の軸色（Blender の View Gizmo に近い赤・緑・青）
AXIS_COLOR = (0xFF4A3DE8, 0xFF38C88A, 0xFFE88835)
# 負方向のボールの塗り（上記を約30%の明るさに落とした色）
AXIS_COLOR_DARK = (0xFF1A1651, 0xFF134630, 0xFF512F12)


class AxisGizmoOverlay:
    """アクティブなビューポートに軸インジケータを1つ描画する。"""

    SLOT_COUNT = 6  # 正負6方向のボール

    def __init__(self, ext_id: str, viewport_window):
        self._viewport_window = viewport_window
        self._frame = viewport_window.get_frame(ext_id)
        self._scene_view = None
        self._axis_lines = []
        self._slot_transforms = []
        self._slot_fills = []
        self._slot_rings = []
        self._slot_labels = []
        self._last_view = None

        self._build_ui()

        self._update_sub = (
            omni.kit.app.get_app()
            .get_update_event_stream()
            .create_subscription_to_pop(self._on_update, name="myext.view_gizmo.update")
        )

    def _build_ui(self):
        self._frame.visible = True
        with self._frame:
            with ui.VStack():
                ui.Spacer(height=MARGIN_TOP_PX)
                with ui.HStack(height=GIZMO_SIZE_PX):
                    ui.Spacer(width=MARGIN_LEFT_PX)
                    self._scene_view = sc.SceneView(
                        width=GIZMO_SIZE_PX, height=GIZMO_SIZE_PX
                    )
                    ui.Spacer()
                ui.Spacer()

        with self._scene_view.scene:
            # 背景の円盤。以降のどの要素よりも先に描いて最背面に置く
            sc.Arc(
                BACKDROP_RADIUS,
                axis=2,
                tesselation=BALL_TESSELATION,
                wireframe=False,
                color=COLOR_BACKDROP,
            )

            # 正方向3本の軸線。ボールより先に描いてボールの下に潜らせる
            for index in range(3):
                self._axis_lines.append(
                    sc.Line(
                        [0.0, 0.0, 0.0],
                        [0.0, 0.0, 0.0],
                        color=AXIS_COLOR[index],
                        thickness=AXIS_LINE_THICKNESS,
                    )
                )

            # ボールのスロット。後に作ったものほど手前に描かれる
            for _ in range(self.SLOT_COUNT):
                transform = sc.Transform()
                with transform:
                    fill = sc.Arc(
                        BALL_RADIUS,
                        axis=2,
                        tesselation=BALL_TESSELATION,
                        wireframe=False,
                        color=COLOR_TRANSPARENT,
                    )
                    ring = sc.Arc(
                        BALL_RADIUS,
                        axis=2,
                        tesselation=BALL_TESSELATION,
                        wireframe=True,
                        thickness=RING_THICKNESS,
                        color=COLOR_TRANSPARENT,
                    )
                    label = sc.Label(
                        "",
                        alignment=ui.Alignment.CENTER,
                        color=COLOR_BALL_TEXT,
                        size=LABEL_SIZE,
                    )
                self._slot_transforms.append(transform)
                self._slot_fills.append(fill)
                self._slot_rings.append(ring)
                self._slot_labels.append(label)

    def _on_update(self, _event):
        viewport_api = self._viewport_window.viewport_api
        if viewport_api is None:
            return

        # view はワールド→カメラの行列。前フレームと同じなら何もしない
        view = viewport_api.view
        if view is None or view == self._last_view:
            return
        self._last_view = Gf.Matrix4d(view)

        # カメラ空間は x=右・y=上・z=手前（USDカメラは -Z 方向を向く）
        endpoints = []
        for index in range(3):
            world_axis = Gf.Vec3d(0.0, 0.0, 0.0)
            world_axis[index] = 1.0
            # TransformDir は平行移動を無視して回転だけを適用する
            direction = view.TransformDir(world_axis)
            length = direction.GetLength()
            if length > 1e-9:
                direction = direction / length

            line = self._axis_lines[index]
            line.start = [0.0, 0.0, 0.0]
            line.end = [
                direction[0] * ORBIT_RADIUS,
                direction[1] * ORBIT_RADIUS,
                0.0,
            ]

            endpoints.append((index, 1, direction))
            endpoints.append((index, -1, -direction))

        # 奥（z が小さい）から順にスロットへ割り当て、手前のボールを後から描く
        endpoints.sort(key=lambda item: item[2][2])
        for slot, (index, sign, direction) in enumerate(endpoints):
            self._slot_transforms[slot].transform = sc.Matrix44.get_translation_matrix(
                direction[0] * ORBIT_RADIUS, direction[1] * ORBIT_RADIUS, 0.0
            )
            if sign > 0:
                self._slot_fills[slot].color = AXIS_COLOR[index]
                self._slot_rings[slot].color = COLOR_TRANSPARENT
                self._slot_labels[slot].text = AXIS_LABELS[index]
                self._slot_labels[slot].color = COLOR_BALL_TEXT
            else:
                self._slot_fills[slot].color = AXIS_COLOR_DARK[index]
                self._slot_rings[slot].color = AXIS_COLOR[index]
                self._slot_labels[slot].text = ""
                self._slot_labels[slot].color = COLOR_TRANSPARENT

    def destroy(self):
        self._update_sub = None
        self._axis_lines = []
        self._slot_transforms = []
        self._slot_fills = []
        self._slot_rings = []
        self._slot_labels = []
        self._scene_view = None
        if self._frame is not None:
            self._frame.clear()
            self._frame.visible = False
        self._frame = None
        self._viewport_window = None


class ViewGizmoExtension(omni.ext.IExt):
    def on_startup(self, ext_id: str):
        self._ext_id = ext_id
        self._overlay = None
        self._visible = False
        self._startup_task = None

        self._menu_items = [
            MenuItemDescription(
                name=MENU_ITEM_NAME,
                ticked=True,
                ticked_fn=self._is_visible,
                onclick_fn=self._on_menu_click,
            )
        ]
        menu_utils.add_menu_items(self._menu_items, MENU_GROUP)

        enabled = carb.settings.get_settings().get(SETTING_ENABLED)
        if enabled is None or bool(enabled):
            self._startup_task = asyncio.ensure_future(self._show_when_viewport_ready())

    def on_shutdown(self):
        if self._startup_task is not None:
            self._startup_task.cancel()
            self._startup_task = None
        self._hide()
        menu_utils.remove_menu_items(self._menu_items, MENU_GROUP)
        self._menu_items = None

    # --- メニュー ---

    def _is_visible(self, *_args) -> bool:
        return self._visible

    def _on_menu_click(self, *_args):
        if self._visible:
            self._hide()
        else:
            self._show()
        menu_utils.refresh_menu_items(MENU_GROUP)

    # --- 表示制御 ---

    async def _show_when_viewport_ready(self):
        """起動直後はビューポートが未生成のことがあるので、出来るまで待つ。"""
        app = omni.kit.app.get_app()
        for _ in range(300):
            if get_active_viewport_window() is not None:
                self._show()
                menu_utils.refresh_menu_items(MENU_GROUP)
                return
            await app.next_update_async()
        carb.log_warn("[myext.view_gizmo] Viewportウィンドウが見つからないため表示を中止した")

    def _show(self):
        if self._overlay is not None:
            return
        viewport_window = get_active_viewport_window()
        if viewport_window is None:
            carb.log_warn("[myext.view_gizmo] アクティブなViewportウィンドウが無い")
            return
        self._overlay = AxisGizmoOverlay(self._ext_id, viewport_window)
        self._visible = True

    def _hide(self):
        if self._overlay is not None:
            self._overlay.destroy()
            self._overlay = None
        self._visible = False
