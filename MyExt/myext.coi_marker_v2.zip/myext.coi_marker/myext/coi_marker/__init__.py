from .extension import CoiMarkerExtension
