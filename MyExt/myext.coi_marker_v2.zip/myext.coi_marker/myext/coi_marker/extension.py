"""Alt キーを押している間、ビューポートカメラの回転中心（Center of Interest, COI）を可視化する。

表示要素:
- 3D マーカー: COI の位置にワールド軸方向の3軸十字（X=赤, Y=緑, Z=青）と中心点
- 距離テキスト: カメラ→COI の距離と、COI の地面からの高さ（m）
- 接地線: COI から地面（up 軸 = 0 の平面）へ下ろした垂線
- 足元円: 接地線の終点に描く地面上の円

入力競合を避ける設計:
- SceneView には gesture を一切付けない。omni.ui はコールバックを持たない
  ウィジェットではマウスイベントを消費しないため、カメラ操作はそのまま通る。
- Alt キーはイベント購読ではなく「毎フレームの状態読み取り（ポーリング）」で
  判定する。イベントを受け取らないので、標準のキー操作から何も奪わない。
- ホットキーは登録しない。ON/OFF は MyExt メニューの1項目のみで切り替える。
- USD ステージには何も書き込まない（読み取りのみ）。
"""

import asyncio
import math

import carb
import carb.input
import carb.settings
import omni.appwindow
import omni.ext
import omni.kit.app
import omni.kit.menu.utils as menu_utils
import omni.ui as ui
from omni.kit.menu.utils import MenuItemDescription
from omni.kit.viewport.utility import get_active_viewport_window
from omni.ui import scene as sc
from pxr import Gf, UsdGeom

EXT_NAME = "myext.coi_marker"
MENU_GROUP = "MyExt"
MENU_ITEM_ENABLED = "COI Marker (Hold Alt)"

SETTING_ENABLED = f"/persistent/exts/{EXT_NAME}/enabled"

# COI を保持する USD 属性名（Kit のビューポートカメラが持つ、カメラローカル座標の点）
COI_ATTR_NAME = "omni:kit:centerOfInterest"

# ---- 見た目の調整値 -------------------------------------------------------
# サイズはすべて「画面上のピクセル数」で指定する。距離に応じてワールド長へ換算する
AXIS_LENGTH_PX = 28.0       # 3軸十字の片側の長さ
AXIS_THICKNESS = 2.0
CENTER_POINT_PX = 7.0       # 中心点の直径
FOOT_RADIUS_PX = 14.0       # 足元円の半径（COI と同じ奥行きにあると仮定した換算）
FOOT_SEGMENTS = 32          # 足元円を近似する線分の数
DROP_LINE_THICKNESS = 1.5
LABEL_SIZE = 14             # 距離テキストの文字サイズ（px）
LABEL_OFFSET_PX = (14.0, 10.0)  # マーカー中心から見たテキストの位置（右, 上）

# omni.ui の色は 0xAABBGGRR
COLOR_AXIS = (0xFF3B3BFF, 0xFF3BFF3B, 0xFFFF6B3B)  # X=赤, Y=緑, Z=青
COLOR_CENTER = 0xFF00E1FF       # 黄
COLOR_DROP_LINE = 0xB300E1FF    # 黄（70%）
COLOR_FOOT = 0xE600E1FF         # 黄（90%）
COLOR_LABEL = 0xFFFFFFFF

FALLBACK_WORLD_PER_PX_RATIO = 0.0015  # 投影行列を解釈できない場合: 距離×この値を1pxとみなす


class CoiMarkerOverlay:
    """アクティブなビューポート1枚に COI マーカーを描画する。"""

    def __init__(self, ext_id: str, viewport_window):
        self._viewport_window = viewport_window
        self._frame = viewport_window.get_frame(ext_id)
        self._scene_view = None
        self._root = None
        self._axis_lines = []
        self._center_transform = None
        self._drop_line = None
        self._foot_lines = []
        self._label_anchor = None
        self._label_dist = None
        self._label_height = None
        self._last_key = None
        self._warned_missing_attr = False

        self._input = carb.input.acquire_input_interface()
        app_window = omni.appwindow.get_default_app_window()
        self._keyboard = app_window.get_keyboard() if app_window else None

        self._build_ui()

        self._update_sub = (
            omni.kit.app.get_app()
            .get_update_event_stream()
            .create_subscription_to_pop(self._on_update, name=f"{EXT_NAME}.update")
        )

    # ---- 構築 --------------------------------------------------------------

    def _build_ui(self):
        self._frame.visible = True
        with self._frame:
            # ビューポートと同じ view/projection で描く SceneView。gesture は付けない
            self._scene_view = sc.SceneView()
        self._viewport_window.viewport_api.add_scene_view(self._scene_view)

        with self._scene_view.scene:
            self._root = sc.Transform(visible=False)
            with self._root:
                # 接地線と足元円はワールド座標で直接描く
                self._drop_line = sc.Line(
                    [0, 0, 0], [0, 0, 0], color=COLOR_DROP_LINE, thickness=DROP_LINE_THICKNESS
                )
                for _ in range(FOOT_SEGMENTS):
                    self._foot_lines.append(
                        sc.Line([0, 0, 0], [0, 0, 0], color=COLOR_FOOT, thickness=DROP_LINE_THICKNESS)
                    )
                # 3軸十字もワールド座標（長さは毎フレーム換算して更新する）
                for index in range(3):
                    self._axis_lines.append(
                        sc.Line([0, 0, 0], [0, 0, 0], color=COLOR_AXIS[index], thickness=AXIS_THICKNESS)
                    )
                self._center_transform = sc.Transform()
                with self._center_transform:
                    sc.Points([[0, 0, 0]], colors=[COLOR_CENTER], sizes=[CENTER_POINT_PX])

                # テキストはカメラ正対・画面ピクセル単位で描く
                self._label_anchor = sc.Transform()
                with self._label_anchor:
                    with sc.Transform(look_at=sc.Transform.LookAt.CAMERA):
                        with sc.Transform(scale_to=sc.Space.SCREEN):
                            with sc.Transform(
                                transform=sc.Matrix44.get_translation_matrix(
                                    LABEL_OFFSET_PX[0], LABEL_OFFSET_PX[1] + LABEL_SIZE + 2, 0
                                )
                            ):
                                self._label_dist = sc.Label(
                                    "", alignment=ui.Alignment.LEFT_BOTTOM, color=COLOR_LABEL, size=LABEL_SIZE
                                )
                            with sc.Transform(
                                transform=sc.Matrix44.get_translation_matrix(
                                    LABEL_OFFSET_PX[0], LABEL_OFFSET_PX[1], 0
                                )
                            ):
                                self._label_height = sc.Label(
                                    "", alignment=ui.Alignment.LEFT_BOTTOM, color=COLOR_LABEL, size=LABEL_SIZE
                                )

    # ---- 毎フレーム --------------------------------------------------------

    def _is_alt_pressed(self) -> bool:
        if self._keyboard is None:
            return False
        left = self._input.get_keyboard_value(self._keyboard, carb.input.KeyboardInput.LEFT_ALT)
        right = self._input.get_keyboard_value(self._keyboard, carb.input.KeyboardInput.RIGHT_ALT)
        return left > 0.0 or right > 0.0

    def _on_update(self, _event):
        if not self._is_alt_pressed():
            self._root.visible = False
            return

        state = self._read_camera_state()
        if state is None:
            self._root.visible = False
            return

        key = state["key"]
        if key != self._last_key:
            self._last_key = key
            self._apply_state(state)
        self._root.visible = True

    def _read_camera_state(self):
        viewport_api = self._viewport_window.viewport_api
        if viewport_api is None:
            return None
        stage = viewport_api.stage
        if stage is None:
            return None
        camera_prim = stage.GetPrimAtPath(viewport_api.camera_path)
        if not camera_prim or not camera_prim.IsValid():
            return None

        coi_attr = self._find_coi_attr(camera_prim)
        if coi_attr is None:
            return None
        coi_local = coi_attr.Get()
        if coi_local is None:
            return None
        coi_local = Gf.Vec3d(coi_local[0], coi_local[1], coi_local[2])

        view = Gf.Matrix4d(viewport_api.view)           # ワールド→カメラ
        projection = Gf.Matrix4d(viewport_api.projection)
        cam_to_world = view.GetInverse()
        coi_world = cam_to_world.Transform(coi_local)
        cam_world = cam_to_world.Transform(Gf.Vec3d(0, 0, 0))
        distance = (coi_world - cam_world).GetLength()

        resolution = viewport_api.resolution
        height_px = float(resolution[1]) if resolution and resolution[1] > 0 else 1080.0
        world_per_px = self._world_per_pixel(projection, distance, height_px)

        up_axis = UsdGeom.GetStageUpAxis(stage)
        meters_per_unit = UsdGeom.GetStageMetersPerUnit(stage) or 1.0

        key = (
            tuple(coi_world),
            tuple(cam_world),
            round(world_per_px, 9),
            up_axis,
            meters_per_unit,
        )
        return {
            "key": key,
            "coi_world": coi_world,
            "distance": distance,
            "world_per_px": world_per_px,
            "up_axis": up_axis,
            "meters_per_unit": meters_per_unit,
        }

    def _find_coi_attr(self, camera_prim):
        attr = camera_prim.GetAttribute(COI_ATTR_NAME)
        if attr and attr.IsValid():
            return attr
        # 属性名がバージョンで変わっていた場合に備え、名前に centerOfInterest を含む属性を探す
        for candidate in camera_prim.GetAttributes():
            if "centerofinterest" in candidate.GetName().lower():
                return candidate
        if not self._warned_missing_attr:
            self._warned_missing_attr = True
            names = [a.GetName() for a in camera_prim.GetAttributes()]
            carb.log_warn(
                f"[{EXT_NAME}] カメラ {camera_prim.GetPath()} に COI 属性が見つからない。属性一覧: {names}"
            )
        return None

    @staticmethod
    def _world_per_pixel(projection: Gf.Matrix4d, distance: float, height_px: float) -> float:
        """COI の奥行きで、画面1ピクセルがワールド長いくつに相当するかを返す。"""
        try:
            p11 = projection[1][1]
            is_ortho = abs(projection[3][3] - 1.0) < 1e-9
            if is_ortho and abs(p11) > 1e-12:
                # 正投影: 画面の縦幅 = 2 / p11（奥行きに依存しない）
                return (2.0 / abs(p11)) / height_px
            if abs(p11) > 1e-12:
                # 透視投影: 奥行き d での画面縦幅 = 2 * d / p11
                return (2.0 * distance / abs(p11)) / height_px
        except Exception:  # noqa: BLE001  投影行列の形式が想定外の場合は近似に落とす
            pass
        return max(distance, 1e-6) * FALLBACK_WORLD_PER_PX_RATIO

    def _apply_state(self, state):
        coi = state["coi_world"]
        wpp = state["world_per_px"]
        up_index = 1 if state["up_axis"] == UsdGeom.Tokens.y else 2
        plane_indices = (0, 2) if up_index == 1 else (0, 1)
        mpu = state["meters_per_unit"]

        # 3軸十字（中心から ±方向へ伸ばす）
        axis_len = AXIS_LENGTH_PX * wpp
        for index in range(3):
            offset = Gf.Vec3d(0, 0, 0)
            offset[index] = axis_len
            self._axis_lines[index].start = list(coi - offset)
            self._axis_lines[index].end = list(coi + offset)

        coi_list = list(coi)
        self._center_transform.transform = sc.Matrix44.get_translation_matrix(*coi_list)
        self._label_anchor.transform = sc.Matrix44.get_translation_matrix(*coi_list)

        # 接地線
        foot = Gf.Vec3d(coi)
        foot[up_index] = 0.0
        self._drop_line.start = coi_list
        self._drop_line.end = list(foot)

        # 足元円（地面上の円を線分で近似）
        radius = FOOT_RADIUS_PX * wpp
        a, b = plane_indices
        points = []
        for i in range(FOOT_SEGMENTS + 1):
            theta = 2.0 * math.pi * i / FOOT_SEGMENTS
            p = Gf.Vec3d(foot)
            p[a] += radius * math.cos(theta)
            p[b] += radius * math.sin(theta)
            points.append(list(p))
        for i, line in enumerate(self._foot_lines):
            line.start = points[i]
            line.end = points[i + 1]

        # テキスト
        distance_m = state["distance"] * mpu
        height_m = coi[up_index] * mpu
        self._label_dist.text = f"COI dist {distance_m:.2f} m"
        self._label_height.text = f"height {height_m:+.2f} m"

    # ---- 破棄 --------------------------------------------------------------

    def destroy(self):
        self._update_sub = None
        if self._scene_view is not None and self._viewport_window is not None:
            viewport_api = self._viewport_window.viewport_api
            if viewport_api is not None:
                try:
                    viewport_api.remove_scene_view(self._scene_view)
                except Exception:  # noqa: BLE001  ビューポート側が先に破棄されている場合
                    pass
        self._axis_lines = []
        self._foot_lines = []
        self._drop_line = None
        self._center_transform = None
        self._label_anchor = None
        self._label_dist = None
        self._label_height = None
        self._root = None
        self._scene_view = None
        if self._frame is not None:
            self._frame.clear()
            self._frame.visible = False
        self._frame = None
        self._viewport_window = None


class CoiMarkerExtension(omni.ext.IExt):
    def on_startup(self, ext_id: str):
        self._ext_id = ext_id
        self._overlay = None
        self._startup_task = None
        self._settings = carb.settings.get_settings()

        self._menu_items = [
            MenuItemDescription(
                name=MENU_ITEM_ENABLED,
                ticked=True,
                ticked_fn=self._is_enabled,
                onclick_fn=self._on_click_enabled,
            ),
        ]
        menu_utils.add_menu_items(self._menu_items, MENU_GROUP)

        if self._is_enabled():
            self._startup_task = asyncio.ensure_future(self._show_when_viewport_ready())

    def on_shutdown(self):
        if self._startup_task is not None:
            self._startup_task.cancel()
            self._startup_task = None
        self._hide()
        menu_utils.remove_menu_items(self._menu_items, MENU_GROUP)
        self._menu_items = None

    # ---- 設定値 ------------------------------------------------------------

    def _is_enabled(self, *_args) -> bool:
        value = self._settings.get(SETTING_ENABLED)
        return True if value is None else bool(value)

    # ---- メニュー ----------------------------------------------------------

    def _on_click_enabled(self, *_args):
        enabled = not self._is_enabled()
        self._settings.set(SETTING_ENABLED, enabled)
        if enabled:
            self._show()
        else:
            self._hide()
        menu_utils.refresh_menu_items(MENU_GROUP)

    # ---- 表示制御 ----------------------------------------------------------

    async def _show_when_viewport_ready(self):
        """起動直後はビューポートが未生成のことがあるので、出来るまで待つ。"""
        app = omni.kit.app.get_app()
        for _ in range(300):
            if get_active_viewport_window() is not None:
                self._show()
                menu_utils.refresh_menu_items(MENU_GROUP)
                return
            await app.next_update_async()
        carb.log_warn(f"[{EXT_NAME}] Viewportウィンドウが見つからないため表示を中止した")

    def _show(self):
        if self._overlay is not None:
            return
        viewport_window = get_active_viewport_window()
        if viewport_window is None:
            carb.log_warn(f"[{EXT_NAME}] アクティブなViewportウィンドウが無い")
            return
        self._overlay = CoiMarkerOverlay(self._ext_id, viewport_window)

    def _hide(self):
        if self._overlay is not None:
            self._overlay.destroy()
            self._overlay = None
