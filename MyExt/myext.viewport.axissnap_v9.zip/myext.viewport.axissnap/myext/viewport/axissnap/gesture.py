"""中ボタンドラッグでカメラを90度ずつ回すカメラジェスチャ。

carb 設定 /exts/omni.kit.viewport.window/bindings/camera に次の2つを登録することで、
Kit のカメラ操作と同じ調停機構（GestureManager）に乗る。

- "myext.viewport.axissnap.gesture.AxisSnapGesture": "Alt MiddleButton"
- "myext.viewport.axissnap.gesture.ViewRollGesture": "Ctrl Alt MiddleButton"
"""

import carb
from omni.kit.manipulator.camera import CameraGestureBase
from omni.kit.viewport.utility import get_active_viewport

from . import animation, camera_ops


class _NinetyDegreeGestureBase(CameraGestureBase):
    """ドラッグ量がしきい値を超えた時点で1回だけ、90度の回転を計画して補間を始める。

    model には値を書き込まない。したがって Kit 標準の Tumble / Pan / Zoom / Look は
    このジェスチャが動いている間、いっさい camera を動かさない。
    派生クラスは _drag_amount と _make_plan を実装する。
    """

    _LABEL = "gesture"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._accumulated_x = 0.0
        self._accumulated_y = 0.0
        self._already_fired = False

    def on_began(self, *args, **kwargs):
        super().on_began(*args, **kwargs)
        self._accumulated_x = 0.0
        self._accumulated_y = 0.0
        self._already_fired = False

    def on_ended(self, *args, **kwargs):
        self._already_fired = False
        super().on_ended(*args, **kwargs)

    def _drag_amount(self) -> float:
        """しきい値と比べるドラッグ量を返す。"""
        raise NotImplementedError

    def _make_plan(self, viewport):
        """SnapPlan を作って返す。作れなければ None を返す。"""
        raise NotImplementedError

    def on_mouse_move(self, mouse_moved):
        # 1 回のドラッグにつき 1 回だけ発火する。ボタンを離すまで追加で回らない。
        if self._already_fired:
            return

        self._accumulated_x += mouse_moved[0]
        self._accumulated_y += mouse_moved[1]

        if self._drag_amount() < camera_ops.get_drag_threshold():
            return

        self._already_fired = True
        camera_ops.debug(
            "%s fired: accumulated=(%.4f, %.4f)"
            % (self._LABEL, self._accumulated_x, self._accumulated_y)
        )

        viewport = get_active_viewport()
        if viewport is None:
            carb.log_warn("[myext.viewport.axissnap] no active viewport")
            return

        try:
            # 補間中に再度ドラッグされた場合、plan は補間途中のカメラの向きから作られる。
            animation.cancel()
            plan = self._make_plan(viewport)
            if plan is not None:
                animation.start(plan)
        except Exception as exc:  # noqa: BLE001 - ジェスチャ内で例外を外に出さない
            carb.log_error("[myext.viewport.axissnap] %s failed: %s" % (self._LABEL, exc))


class AxisSnapGesture(_NinetyDegreeGestureBase):
    """Alt + 中ボタンドラッグ：サイコロを転がすように、画面の上または右を軸に90度回す。"""

    _LABEL = "axis snap"

    def _drag_amount(self) -> float:
        return camera_ops.magnitude(self._accumulated_x, self._accumulated_y)

    def _make_plan(self, viewport):
        return camera_ops.plan_axis_snap(viewport, self._accumulated_x, self._accumulated_y)


class ViewRollGesture(_NinetyDegreeGestureBase):
    """Ctrl + Alt + 中ボタンドラッグ：視線方向を軸に90度回す。横方向のドラッグだけを見る。"""

    _LABEL = "view roll"

    def _drag_amount(self) -> float:
        return abs(self._accumulated_x)

    def _make_plan(self, viewport):
        return camera_ops.plan_view_roll(viewport, self._accumulated_x)
