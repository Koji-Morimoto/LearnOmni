"""軸整列の視点移動を、毎フレーム少しずつ進める補間処理。

omni.kit.app の next_update_async() を使い、1フレームごとに経過時間を足しながら
カメラの向きを開始から終了へ近づける。
"""

import asyncio

import carb
import omni.kit.app

from . import camera_ops

# 実行中の補間タスク。新しい整列が始まったら前のものを取り消すために保持する。
_current_task = None


def cancel() -> None:
    """実行中の補間を止める。止めた時点の向きでカメラは残る。"""
    global _current_task
    if _current_task is not None and not _current_task.done():
        _current_task.cancel()
    _current_task = None


def start(plan: "camera_ops.SnapPlan") -> None:
    """補間を開始する。補間時間が 0 以下なら即座に終了状態へ移る。"""
    global _current_task
    cancel()

    duration = camera_ops.get_animation_duration()
    if duration <= 0.0:
        camera_ops.finish(plan)
        return

    _current_task = asyncio.ensure_future(_run(plan, duration))


async def _run(plan: "camera_ops.SnapPlan", duration: float) -> None:
    app = omni.kit.app.get_app()
    elapsed = 0.0
    try:
        while elapsed < duration:
            dt = await app.next_update_async()
            # 補間中にビューポートのカメラが切り替えられたら、切替前のカメラを動かし続けない。
            if str(plan.viewport.camera_path) != str(plan.camera_path):
                camera_ops.debug(
                    "camera switched from %s to %s during animation; abort"
                    % (plan.camera_path, plan.viewport.camera_path)
                )
                return
            elapsed += float(dt)
            t = min(elapsed / duration, 1.0)
            rotation = camera_ops.slerp(
                plan.start_rotation, plan.end_rotation, camera_ops.ease_in_out_cubic(t)
            )
            if not camera_ops.apply_orientation(plan, rotation):
                return
        camera_ops.finish(plan)
        camera_ops.debug("animation finished")

        # 書き込み直後・1フレーム後・10フレーム後に、カメラの実際の向きを読み戻す。
        camera_ops.debug_readback(plan, "+0 frame")
        await app.next_update_async()
        camera_ops.debug_readback(plan, "+1 frame")
        for _ in range(9):
            await app.next_update_async()
        camera_ops.debug_readback(plan, "+10 frames")
    except asyncio.CancelledError:
        # 途中で新しい整列が始まった、または拡張機能が無効化された。
        # 平行投影への切り替えは行わず、その時点の向きのまま残す。
        pass
    except Exception as exc:  # noqa: BLE001 - フレーム処理の例外で Kit を止めない
        carb.log_error("[myext.viewport.axissnap] animation failed: %s" % exc)
