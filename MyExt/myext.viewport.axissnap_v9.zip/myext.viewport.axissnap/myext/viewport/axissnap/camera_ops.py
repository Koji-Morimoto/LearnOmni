"""ビューポートカメラを軸ビューへ整列させ、平行投影へ切り替える処理をまとめる。

処理は3つの関数に分かれている。
- plan_axis_snap : 現在のカメラ状態とドラッグ方向から、開始と終了の向きを計算する（書き込みはしない）
- apply_orientation : 与えられた向きでカメラを置く。補間の各フレームで呼ばれる
- finish : 補間の最後に1回だけ呼ばれ、平行投影への切り替えを行う

このモジュールは USD のカメラ prim を直接書き換える。
omni.kit.manipulator.camera の model には一切値を入れないので、
既存の Tumble / Pan / Zoom ジェスチャの動作とは干渉しない。
"""

import math
from dataclasses import dataclass

import carb
import carb.settings
from pxr import Gf, Sdf, Usd, UsdGeom

SETTINGS_ROOT = "/exts/myext.viewport.axissnap"
SETTING_MAKE_ORTHO = SETTINGS_ROOT + "/make_orthographic"
SETTING_INVERT_H = SETTINGS_ROOT + "/invert_horizontal"
SETTING_INVERT_V = SETTINGS_ROOT + "/invert_vertical"
SETTING_INVERT_ROLL = SETTINGS_ROOT + "/invert_roll"
SETTING_THRESHOLD = SETTINGS_ROOT + "/drag_threshold"
SETTING_DURATION = SETTINGS_ROOT + "/animation_duration"
SETTING_DEBUG = SETTINGS_ROOT + "/debug_log"

# 平行投影へ切り替える前の透視投影パラメータを prim の customData に退避するキー。
_SAVED_PERSP_KEY = "myext_axissnap_saved_perspective"

# Kit のカメラ prim が持つ注視点（カメラローカル座標）の属性名。
_CENTER_OF_INTEREST_ATTR = "omni:kit:centerOfInterest"

# USD のカメラでは、aperture 値 × 0.1 がワールド単位の長さになる。
_APERTURE_UNIT = 0.1


@dataclass
class SnapPlan:
    """1回の軸整列に必要な情報。補間の全フレームで同じものを使い回す。"""

    viewport: object
    stage: Usd.Stage
    camera_path: Sdf.Path
    parent_world_inverse: Gf.Matrix4d
    center_world: Gf.Vec3d
    distance: float
    start_rotation: Gf.Quatd
    end_rotation: Gf.Quatd


# ----------------------------------------------------------------------
# 設定値の読み出し
# ----------------------------------------------------------------------
def _get_setting_bool(path: str, default: bool) -> bool:
    value = carb.settings.get_settings().get(path)
    return default if value is None else bool(value)


def _get_setting_float(path: str, default: float) -> float:
    value = carb.settings.get_settings().get(path)
    return default if value is None else float(value)


def get_drag_threshold() -> float:
    return _get_setting_float(SETTING_THRESHOLD, 0.02)


def get_animation_duration() -> float:
    return max(0.0, _get_setting_float(SETTING_DURATION, 0.4))


def debug(message: str) -> None:
    """extension.toml の debug_log が true のときだけ、コンソールに警告レベルで出す。"""
    if _get_setting_bool(SETTING_DEBUG, False):
        carb.log_warn("[myext.viewport.axissnap][debug] " + message)


# ----------------------------------------------------------------------
# 幾何の補助関数
# ----------------------------------------------------------------------
def _snap_to_nearest_axis(direction: Gf.Vec3d) -> Gf.Vec3d:
    """ベクトルを ±X / ±Y / ±Z のうち最も近い単位軸へ丸める。"""
    components = [abs(direction[0]), abs(direction[1]), abs(direction[2])]
    index = components.index(max(components))
    snapped = Gf.Vec3d(0.0, 0.0, 0.0)
    snapped[index] = 1.0 if direction[index] >= 0.0 else -1.0
    return snapped


def _snap_frame(forward: Gf.Vec3d, up: Gf.Vec3d):
    """右・上・視線の3本の軸を、各軸がワールドの ±X / ±Y / ±Z に揃った最寄りの向きへ丸める。

    視線を先に最寄りの軸へ丸め、次に上方向を「視線に使った軸以外」の中から最寄りの軸へ丸め、
    右方向は2本の外積で決める。3本を独立に丸めると、2本が同じ軸に重なる場合があるため、
    この順序で1本ずつ候補を減らす。
    """
    snapped_forward = _snap_to_nearest_axis(forward)
    forward_index = [abs(snapped_forward[i]) for i in range(3)].index(1.0)

    candidates = [abs(up[i]) if i != forward_index else -1.0 for i in range(3)]
    up_index = candidates.index(max(candidates))
    snapped_up = Gf.Vec3d(0.0, 0.0, 0.0)
    snapped_up[up_index] = 1.0 if up[up_index] >= 0.0 else -1.0

    snapped_right = Gf.Cross(snapped_forward, snapped_up).GetNormalized()
    return snapped_right, snapped_up, snapped_forward


def _rotation_from_basis(right: Gf.Vec3d, up: Gf.Vec3d, forward: Gf.Vec3d) -> Gf.Quatd:
    """カメラの右・上・視線方向から、回転を表す四元数を作る。"""
    matrix = Gf.Matrix4d(1.0)
    matrix.SetRow3(0, right)
    matrix.SetRow3(1, up)
    matrix.SetRow3(2, -forward)  # カメラはローカル -Z を見る
    return matrix.ExtractRotationQuat().GetNormalized()


def _basis_from_rotation(rotation: Gf.Quatd):
    """四元数から、カメラの右・上・視線方向を取り出す。"""
    matrix = Gf.Matrix4d(1.0)
    matrix.SetRotate(rotation)
    right = Gf.Vec3d(matrix.GetRow3(0)).GetNormalized()
    up = Gf.Vec3d(matrix.GetRow3(1)).GetNormalized()
    forward = -Gf.Vec3d(matrix.GetRow3(2)).GetNormalized()
    return right, up, forward


def slerp(start: Gf.Quatd, end: Gf.Quatd, t: float) -> Gf.Quatd:
    """2つの四元数の間を、回転角が一定の速さで進むように補間する（球面線形補間）。"""
    s_real, s_imag = start.GetReal(), Gf.Vec3d(start.GetImaginary())
    e_real, e_imag = end.GetReal(), Gf.Vec3d(end.GetImaginary())

    dot = s_real * e_real + Gf.Dot(s_imag, e_imag)
    # q と -q は同じ回転を表す。内積が負なら片方を反転して、短い側の経路を通らせる。
    if dot < 0.0:
        e_real, e_imag, dot = -e_real, -e_imag, -dot

    if dot > 0.9995:
        # ほぼ同じ向き：角度が小さすぎて sin の割り算が不安定になるので線形補間で代用する
        real = s_real + (e_real - s_real) * t
        imag = s_imag + (e_imag - s_imag) * t
    else:
        theta = math.acos(dot)
        sin_theta = math.sin(theta)
        w_start = math.sin((1.0 - t) * theta) / sin_theta
        w_end = math.sin(t * theta) / sin_theta
        real = s_real * w_start + e_real * w_end
        imag = s_imag * w_start + e_imag * w_end

    return Gf.Quatd(real, imag).GetNormalized()


def ease_in_out_cubic(t: float) -> float:
    """開始直後と終了直前をゆっくり、中間を速く進める変換。0→0、1→1 を保つ。"""
    if t < 0.5:
        return 4.0 * t * t * t
    return 1.0 - math.pow(-2.0 * t + 2.0, 3) / 2.0


# ----------------------------------------------------------------------
# 注視点
# ----------------------------------------------------------------------
def _read_center_of_interest(cam_prim: Usd.Prim, fallback_distance: float) -> Gf.Vec3d:
    """カメラローカル座標での注視点を返す。属性が無ければ -Z 方向の既定距離を使う。"""
    attr = cam_prim.GetAttribute(_CENTER_OF_INTEREST_ATTR)
    if attr and attr.HasAuthoredValue():
        value = attr.Get()
        if value is not None:
            return Gf.Vec3d(value)
    return Gf.Vec3d(0.0, 0.0, -abs(fallback_distance))


# ----------------------------------------------------------------------
# 計画
# ----------------------------------------------------------------------
@dataclass
class _CameraState:
    """計画を立てるときに読み取るカメラの現在の状態。"""

    stage: Usd.Stage
    camera_path: Sdf.Path
    parent_world_inverse: Gf.Matrix4d
    right: Gf.Vec3d
    up: Gf.Vec3d
    forward: Gf.Vec3d
    center_world: Gf.Vec3d
    distance: float


def _read_camera_state(viewport):
    """ビューポートが今使っているカメラの向き・注視点・距離を読み取る。取れなければ None を返す。"""
    stage = viewport.stage
    if stage is None:
        debug("viewport has no stage; abort")
        return None
    camera_path = Sdf.Path(str(viewport.camera_path))
    cam_prim = stage.GetPrimAtPath(camera_path)
    if not cam_prim or not cam_prim.IsValid():
        carb.log_warn("[myext.viewport.axissnap] camera prim %s not found" % camera_path)
        return None

    coi_attr = cam_prim.GetAttribute(_CENTER_OF_INTEREST_ATTR)
    debug(
        "camera=%s projection=%s xformOpOrder=%s centerOfInterest=%s"
        % (
            camera_path,
            UsdGeom.Camera(cam_prim).GetProjectionAttr().Get(),
            list(UsdGeom.Xformable(cam_prim).GetXformOpOrderAttr().Get() or []),
            coi_attr.Get() if coi_attr and coi_attr.HasAuthoredValue() else "none",
        )
    )

    xform_cache = UsdGeom.XformCache(Usd.TimeCode.Default())
    world = xform_cache.GetLocalToWorldTransform(cam_prim)

    parent = cam_prim.GetParent()
    if parent and parent.IsValid() and not parent.IsPseudoRoot():
        parent_world_inverse = xform_cache.GetLocalToWorldTransform(parent).GetInverse()
    else:
        parent_world_inverse = Gf.Matrix4d(1.0)

    center_local = _read_center_of_interest(cam_prim, fallback_distance=500.0)
    distance = center_local.GetLength()
    if distance < 1e-6:
        distance = 500.0

    # Gf.Matrix4d は行ベクトル規約なので、基底ベクトルは各行に入る。
    return _CameraState(
        stage=stage,
        camera_path=camera_path,
        parent_world_inverse=parent_world_inverse,
        right=Gf.Vec3d(world.GetRow3(0)).GetNormalized(),
        up=Gf.Vec3d(world.GetRow3(1)).GetNormalized(),
        forward=-Gf.Vec3d(world.GetRow3(2)).GetNormalized(),
        center_world=world.Transform(center_local),
        distance=distance,
    )


def _plan_from_rotation(viewport, state: _CameraState, rotation: Gf.Rotation, label: str) -> SnapPlan:
    """カメラの3本の軸を rotation でまとめて回し、最寄りの揃った向きへ丸めた SnapPlan を作る。

    上方向を決め直さないので、どの向きから回したかが終了時の向きにそのまま引き継がれる。
    開始時に軸へ揃っていなかった場合（自由に周回した後など）だけ、丸めで向きが補正される。
    """
    rolled_forward = Gf.Vec3d(rotation.TransformDir(state.forward)).GetNormalized()
    rolled_up = Gf.Vec3d(rotation.TransformDir(state.up)).GetNormalized()
    target_right, target_up, target_forward = _snap_frame(rolled_forward, rolled_up)

    debug(
        "%s: start(forward=%s up=%s) -> target(forward=%s up=%s) distance=%.3f"
        % (label, _fmt(state.forward), _fmt(state.up), _fmt(target_forward), _fmt(target_up), state.distance)
    )

    return SnapPlan(
        viewport=viewport,
        stage=state.stage,
        camera_path=state.camera_path,
        parent_world_inverse=state.parent_world_inverse,
        center_world=state.center_world,
        distance=state.distance,
        start_rotation=_rotation_from_basis(state.right, state.up, state.forward),
        end_rotation=_rotation_from_basis(target_right, target_up, target_forward),
    )


def plan_axis_snap(viewport, accumulated_x: float, accumulated_y: float):
    """サイコロを転がすように、画面の上または右を軸にカメラを90度回す SnapPlan を作る。

    横方向のドラッグが大きければカメラの上方向まわり、縦方向が大きければカメラの右方向まわりに回す。
    カメラが取得できない場合は None を返す。書き込みは行わない。
    """
    state = _read_camera_state(viewport)
    if state is None:
        return None

    if abs(accumulated_x) >= abs(accumulated_y):
        angle = -90.0 if accumulated_x > 0.0 else 90.0
        if _get_setting_bool(SETTING_INVERT_H, False):
            angle = -angle
        rotation = Gf.Rotation(state.up, angle)
    else:
        angle = 90.0 if accumulated_y > 0.0 else -90.0
        if _get_setting_bool(SETTING_INVERT_V, False):
            angle = -angle
        rotation = Gf.Rotation(state.right, angle)

    return _plan_from_rotation(viewport, state, rotation, "roll")


def plan_view_roll(viewport, accumulated_x: float):
    """視線方向を軸にカメラを90度回す SnapPlan を作る。

    右へドラッグ（accumulated_x が正）すると画面の中身が時計回りに回る。
    視線方向・カメラの位置・注視点は変わらず、画面の右と上だけが入れ替わる。
    カメラが取得できない場合は None を返す。書き込みは行わない。
    """
    state = _read_camera_state(viewport)
    if state is None:
        return None

    # 視線方向を軸に +90 度回すと、カメラ自身が（視線の先から見て）時計回りに回るので、
    # 画面の中身は反時計回りに回る。右ドラッグで中身を時計回りにするため、右ドラッグを -90 度にする。
    angle = -90.0 if accumulated_x > 0.0 else 90.0
    if _get_setting_bool(SETTING_INVERT_ROLL, False):
        angle = -angle
    rotation = Gf.Rotation(state.forward, angle)

    return _plan_from_rotation(viewport, state, rotation, "view roll")


# ----------------------------------------------------------------------
# 書き込み先のレイヤ
# ----------------------------------------------------------------------
def _edit_target_for(prim: Usd.Prim) -> Usd.EditTarget:
    """prim への書き込み先を決める。

    Kit 標準のビューポートカメラ（/OmniverseKit_Persp など）はセッションレイヤに定義されている。
    セッションレイヤは最も強いレイヤなので、ルートレイヤへ書き込むとセッションレイヤの値に
    上書きされて見た目が変わらず、しかも利用者のシーンファイルに不要な記述が残る。
    そこで、セッションレイヤに prim の記述がある場合はセッションレイヤへ書き込む。
    """
    stage = prim.GetStage()
    session = stage.GetSessionLayer()
    if session is not None and session.GetPrimAtPath(prim.GetPath()):
        return stage.GetEditTargetForLocalLayer(session)
    return stage.GetEditTarget()


# ----------------------------------------------------------------------
# 変換の書き込み（既存の xformOp の並びを崩さない）
# ----------------------------------------------------------------------
_EULER_AXES = {
    UsdGeom.XformOp.TypeRotateXYZ: ("X", "Y", "Z"),
    UsdGeom.XformOp.TypeRotateXZY: ("X", "Z", "Y"),
    UsdGeom.XformOp.TypeRotateYXZ: ("Y", "X", "Z"),
    UsdGeom.XformOp.TypeRotateYZX: ("Y", "Z", "X"),
    UsdGeom.XformOp.TypeRotateZXY: ("Z", "X", "Y"),
    UsdGeom.XformOp.TypeRotateZYX: ("Z", "Y", "X"),
}
_AXIS_VECTORS = {
    "X": Gf.Vec3d(1.0, 0.0, 0.0),
    "Y": Gf.Vec3d(0.0, 1.0, 0.0),
    "Z": Gf.Vec3d(0.0, 0.0, 1.0),
}


def _vec3_for(op: UsdGeom.XformOp, value: Gf.Vec3d):
    precision = op.GetPrecision()
    if precision == UsdGeom.XformOp.PrecisionFloat:
        return Gf.Vec3f(value)
    if precision == UsdGeom.XformOp.PrecisionHalf:
        return Gf.Vec3h(value)
    return Gf.Vec3d(value)


def _quat_for(op: UsdGeom.XformOp, value: Gf.Quatd):
    real, imag = value.GetReal(), value.GetImaginary()
    precision = op.GetPrecision()
    if precision == UsdGeom.XformOp.PrecisionFloat:
        return Gf.Quatf(real, Gf.Vec3f(imag))
    if precision == UsdGeom.XformOp.PrecisionHalf:
        return Gf.Quath(real, Gf.Vec3h(imag))
    return Gf.Quatd(real, Gf.Vec3d(imag))


def _euler_angles(rotation: Gf.Rotation, axes) -> Gf.Vec3d:
    """回転を、rotateXYZ などの xformOp が期待する3つの角度（度）に分解する。

    戻り値の成分は、X・Y・Z それぞれの軸まわりの角度を X・Y・Z の順に並べたものである。
    xformOp の型名（XYZ・YXZ など）は回転を適用する順序を表し、値の並び自体は常に X・Y・Z の順になる。

    Gf.Rotation.Decompose は、型名の軸順序を逆に並べて渡したときに xformOp の定義と一致する角度を返す。
    （型名どおりの順序で渡すと、ランダムな回転 20 個すべてで不一致になることを実測で確認している）
    """
    decompose_order = tuple(reversed(axes))
    angles = rotation.Decompose(*[_AXIS_VECTORS[a] for a in decompose_order])
    by_axis = dict(zip(decompose_order, angles))
    return Gf.Vec3d(by_axis["X"], by_axis["Y"], by_axis["Z"])


def _rotation_matches(op: UsdGeom.XformOp, expected: Gf.Matrix4d) -> bool:
    """op に書いた値が表す回転が、狙いの回転と一致しているかを確かめる。"""
    actual = op.GetOpTransform(Usd.TimeCode.Default())
    return all(
        abs(actual[i][j] - expected[i][j]) < 1e-4 for i in range(3) for j in range(3)
    )


def _is_plain_op(op: UsdGeom.XformOp) -> bool:
    """接尾辞（xformOp:translate:pivot の pivot など）も逆変換指定も無い op かどうか。"""
    return len(op.GetOpName().split(":")) == 2 and not op.IsInverseOp()


def _write_local_transform(cam_prim: Usd.Prim, local: Gf.Matrix4d) -> bool:
    """親から見た変換 local（回転と平行移動のみ）を、prim の既存の xformOp に書き込む。

    対応する xformOp の並びは次の2通りである。どちらにも当てはまらない場合は何も書かずに False を返す。
    xformOp の並びそのもの（xformOpOrder）は変更しない。

    - xformOp:transform が1つだけ
    - xformOp:translate → 回転の op 1つ（orient または rotateXYZ 系）→ xformOp:scale（省略可）
    """
    xformable = UsdGeom.Xformable(cam_prim)
    ops = xformable.GetOrderedXformOps()
    op_types = [op.GetOpType() for op in ops]

    if op_types == [UsdGeom.XformOp.TypeTransform] and _is_plain_op(ops[0]):
        ops[0].Set(local)
        return True

    translate_op = rotate_op = None
    rest = list(ops)
    if rest and rest[0].GetOpType() == UsdGeom.XformOp.TypeTranslate and _is_plain_op(rest[0]):
        translate_op = rest.pop(0)
    if rest and _is_plain_op(rest[0]) and (
        rest[0].GetOpType() == UsdGeom.XformOp.TypeOrient or rest[0].GetOpType() in _EULER_AXES
    ):
        rotate_op = rest.pop(0)
    if rest and rest[0].GetOpType() == UsdGeom.XformOp.TypeScale and _is_plain_op(rest[0]):
        rest.pop(0)

    if translate_op is None or rotate_op is None or rest:
        carb.log_warn(
            "[myext.viewport.axissnap] unsupported xformOpOrder on %s: %s (camera left unchanged)"
            % (cam_prim.GetPath(), [op.GetOpName() for op in ops])
        )
        return False

    translate_op.Set(_vec3_for(translate_op, local.ExtractTranslation()))
    if rotate_op.GetOpType() == UsdGeom.XformOp.TypeOrient:
        rotate_op.Set(_quat_for(rotate_op, local.ExtractRotationQuat().GetNormalized()))
    else:
        angles = _euler_angles(local.ExtractRotation(), _EULER_AXES[rotate_op.GetOpType()])
        rotate_op.Set(_vec3_for(rotate_op, angles))

    # 書いた値が狙いの回転を再現しているかを毎回照合する。分解の誤りをその場で検出するため。
    expected = Gf.Matrix4d(1.0)
    expected.SetRotate(local.ExtractRotationQuat().GetNormalized())
    if not _rotation_matches(rotate_op, expected):
        carb.log_warn(
            "[myext.viewport.axissnap] written %s value does not reproduce the target rotation on %s"
            % (rotate_op.GetOpName(), cam_prim.GetPath())
        )
    return True


def apply_orientation(plan: SnapPlan, rotation: Gf.Quatd) -> bool:
    """注視点を中心に、与えられた向きでカメラを置く。書き込めた場合に True を返す。

    位置は「注視点から視線方向の逆向きに distance だけ離れた点」に置く。
    向きだけを補間し、位置はそこから毎回導き直すので、カメラは注視点を中心とする
    球面上を移動する（物体を突き抜ける直線経路を通らない）。
    """
    cam_prim = plan.stage.GetPrimAtPath(plan.camera_path)
    if not cam_prim or not cam_prim.IsValid():
        debug("camera prim %s became invalid; stop writing" % plan.camera_path)
        return False

    right, up, forward = _basis_from_rotation(rotation)
    position = plan.center_world - forward * plan.distance

    world = Gf.Matrix4d(1.0)
    world.SetRow3(0, right)
    world.SetRow3(1, up)
    world.SetRow3(2, -forward)
    world.SetRow3(3, position)

    with Usd.EditContext(plan.stage, _edit_target_for(cam_prim)):
        if not _write_local_transform(cam_prim, world * plan.parent_world_inverse):
            return False

        # 注視点はカメラローカルで -Z 方向・同じ距離に保つ。以後の Alt+左ドラッグの
        # 周回中心が移動前と同じ点のままになる。
        coi_attr = cam_prim.GetAttribute(_CENTER_OF_INTEREST_ATTR)
        if coi_attr:
            coi_attr.Set(Gf.Vec3d(0.0, 0.0, -plan.distance))
    return True


def _switch_to_orthographic(cam_prim: Usd.Prim, distance: float) -> None:
    """現在の透視投影での見え方の高さを保ったまま平行投影へ切り替える。"""
    camera = UsdGeom.Camera(cam_prim)
    projection_attr = camera.GetProjectionAttr()
    if projection_attr.Get() == UsdGeom.Tokens.orthographic:
        return

    focal_length = camera.GetFocalLengthAttr().Get()
    horizontal_aperture = camera.GetHorizontalApertureAttr().Get()
    vertical_aperture = camera.GetVerticalApertureAttr().Get()
    if not focal_length or not vertical_aperture:
        carb.log_warn(
            "[myext.viewport.axissnap] focalLength or verticalAperture unavailable; "
            "skip orthographic switch"
        )
        return

    cam_prim.SetCustomDataByKey(
        _SAVED_PERSP_KEY,
        {
            "focalLength": float(focal_length),
            "horizontalAperture": float(horizontal_aperture),
            "verticalAperture": float(vertical_aperture),
        },
    )

    # 透視投影で距離 distance にある平面の高さ = distance * verticalAperture / focalLength
    world_height = distance * float(vertical_aperture) / float(focal_length)
    aspect = float(horizontal_aperture) / float(vertical_aperture)

    camera.GetVerticalApertureAttr().Set(world_height / _APERTURE_UNIT)
    camera.GetHorizontalApertureAttr().Set(world_height * aspect / _APERTURE_UNIT)
    projection_attr.Set(UsdGeom.Tokens.orthographic)


def finish(plan: SnapPlan) -> None:
    """補間の最後に1回だけ呼ぶ。終了時の向きを確定させ、必要なら平行投影へ切り替える。"""
    if not apply_orientation(plan, plan.end_rotation):
        return
    if _get_setting_bool(SETTING_MAKE_ORTHO, False):
        cam_prim = plan.stage.GetPrimAtPath(plan.camera_path)
        with Usd.EditContext(plan.stage, _edit_target_for(cam_prim)):
            _switch_to_orthographic(cam_prim, plan.distance)


def restore_perspective(cam_prim: Usd.Prim) -> bool:
    """平行投影へ切り替える前の透視投影パラメータへ戻す。戻せた場合に True を返す。"""
    saved = cam_prim.GetCustomDataByKey(_SAVED_PERSP_KEY)
    if not saved:
        return False

    with Usd.EditContext(cam_prim.GetStage(), _edit_target_for(cam_prim)):
        camera = UsdGeom.Camera(cam_prim)
        camera.GetFocalLengthAttr().Set(float(saved["focalLength"]))
        camera.GetHorizontalApertureAttr().Set(float(saved["horizontalAperture"]))
        camera.GetVerticalApertureAttr().Set(float(saved["verticalAperture"]))
        camera.GetProjectionAttr().Set(UsdGeom.Tokens.perspective)
        cam_prim.ClearCustomDataByKey(_SAVED_PERSP_KEY)
    return True


def _fmt(v) -> str:
    return "(%+.2f, %+.2f, %+.2f)" % (v[0], v[1], v[2])


def debug_readback(plan: SnapPlan, label: str) -> None:
    """カメラの実際の向きを USD から読み戻し、狙いの向きとの差をログに出す。

    書き込んだ値が効いているか、書き込み後に別の処理がカメラを書き換えていないかを調べるためのもの。
    """
    if not _get_setting_bool(SETTING_DEBUG, False):
        return
    cam_prim = plan.stage.GetPrimAtPath(plan.camera_path)
    if not cam_prim or not cam_prim.IsValid():
        debug("readback %s: camera prim invalid" % label)
        return
    world = UsdGeom.XformCache(Usd.TimeCode.Default()).GetLocalToWorldTransform(cam_prim)
    up = Gf.Vec3d(world.GetRow3(1)).GetNormalized()
    forward = -Gf.Vec3d(world.GetRow3(2)).GetNormalized()
    _, target_up, target_forward = _basis_from_rotation(plan.end_rotation)
    debug(
        "readback %s: forward=%s up=%s | target forward=%s up=%s | match=%s"
        % (
            label,
            _fmt(forward),
            _fmt(up),
            _fmt(target_forward),
            _fmt(target_up),
            (forward - target_forward).GetLength() < 1e-3 and (up - target_up).GetLength() < 1e-3,
        )
    )


def magnitude(x: float, y: float) -> float:
    return math.hypot(x, y)
