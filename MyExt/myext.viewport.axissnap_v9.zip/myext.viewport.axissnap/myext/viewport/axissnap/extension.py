"""メインメニューバーの「MyExt」メニューと、カメラ操作バインドの ON/OFF を管理する拡張本体。

挙動の設定（平行投影への切り替え・回転方向の反転・補間時間など）は
config/extension.toml の [settings] で行う。UI はメニュー項目のチェック1つだけである。
"""

import carb
import carb.settings
import omni.ext
import omni.kit.menu.utils
import omni.usd
from omni.kit.menu.utils import MenuItemDescription
from pxr import UsdGeom

from . import animation, camera_ops

# Kit のカメラ操作バインドが入っている carb 設定のパス。
BINDINGS_PATH = "/exts/omni.kit.viewport.window/bindings/camera"

# 自作ジェスチャの登録キー。import 可能な完全修飾名でなければならない。
GESTURE_KEY = "myext.viewport.axissnap.gesture.AxisSnapGesture"
ROLL_GESTURE_KEY = "myext.viewport.axissnap.gesture.ViewRollGesture"

# メインメニューバーに追加するメニュー名。自作の拡張機能はすべてこの名前のメニューにまとめる。
MENU_GROUP = "MyExt"
MENU_ITEM_NAME = "Blender風 軸スナップ"


class AxisSnapExtension(omni.ext.IExt):
    def on_startup(self, ext_id):
        self._settings = carb.settings.get_settings()
        self._saved_bindings = None
        self._enabled = False

        # 既定で ON にする。
        self._enable_binding()

        self._menu_items = [
            MenuItemDescription(
                name=MENU_ITEM_NAME,
                ticked=True,
                ticked_fn=lambda: self._enabled,
                onclick_fn=self._on_menu_clicked,
            )
        ]
        omni.kit.menu.utils.add_menu_items(self._menu_items, MENU_GROUP)

    def on_shutdown(self):
        omni.kit.menu.utils.remove_menu_items(self._menu_items, MENU_GROUP)
        self._menu_items = []
        self._disable_binding()

    # ------------------------------------------------------------------
    # メニュー
    # ------------------------------------------------------------------
    def _on_menu_clicked(self, *args, **kwargs):
        if self._enabled:
            self._disable_binding()
        else:
            self._enable_binding()
        # チェック表示を現在の状態に合わせて描き直す。
        refresh = getattr(omni.kit.menu.utils, "refresh_menu_items", None)
        if refresh is not None:
            refresh(MENU_GROUP)

    # ------------------------------------------------------------------
    # バインドの ON/OFF
    # ------------------------------------------------------------------
    def _enable_binding(self):
        if self._enabled:
            return

        current = self._settings.get(BINDINGS_PATH)
        if not isinstance(current, dict):
            carb.log_error(
                "[myext.viewport.axissnap] %s is not a dict; "
                "camera bindings format may differ in this Kit version" % BINDINGS_PATH
            )
            return

        self._saved_bindings = dict(current)

        new_bindings = dict(current)
        # 既定の PanGesture は "Any MiddleButton"（修飾キー不問）なので、
        # 修飾キー無しの中ボタンだけに狭めて Alt + 中ボタンを空ける。
        new_bindings["PanGesture"] = "MiddleButton"
        new_bindings[GESTURE_KEY] = "Alt MiddleButton"
        # 修飾キーは完全一致で判定されるので、Alt だけのサイコロ転がしとは衝突しない。
        new_bindings[ROLL_GESTURE_KEY] = "Ctrl Alt MiddleButton"

        self._settings.set(BINDINGS_PATH, new_bindings)
        self._enabled = True
        camera_ops.debug("bindings replaced: %s" % new_bindings)

    def _disable_binding(self):
        animation.cancel()
        self._restore_all_perspective()
        if not self._enabled:
            return
        if self._saved_bindings is not None:
            self._settings.set(BINDINGS_PATH, self._saved_bindings)
        self._saved_bindings = None
        self._enabled = False
        camera_ops.debug("bindings restored")

    def _restore_all_perspective(self):
        """この拡張機能が平行投影に切り替えたカメラを、すべて透視投影へ戻す。

        平行投影へ切り替えたカメラだけが customData に透視投影の値を退避しているので、
        退避値を持たないカメラは restore_perspective の中で何もされずに終わる。
        """
        stage = omni.usd.get_context().get_stage()
        if stage is None:
            return
        for prim in stage.Traverse():
            if prim.IsA(UsdGeom.Camera) and camera_ops.restore_perspective(prim):
                camera_ops.debug("restored perspective: %s" % prim.GetPath())
