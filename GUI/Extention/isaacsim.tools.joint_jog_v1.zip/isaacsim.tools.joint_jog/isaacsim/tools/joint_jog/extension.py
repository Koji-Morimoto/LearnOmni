# SPDX-License-Identifier: Apache-2.0
"""Kit 拡張のエントリポイント。

拡張の有効化でツールバーボタンと設定ウィンドウを登録し、
無効化で登録を全部戻す。
"""

from __future__ import annotations

import traceback

import carb
import omni.ext

from .tool import JointJogTool


class JointJogExtension(omni.ext.IExt):
    """Joint Jog 拡張。"""

    def __init__(self) -> None:
        super().__init__()
        self._tool: JointJogTool | None = None

    def on_startup(self, ext_id: str) -> None:
        """拡張が有効化されたときに呼ばれる。

        Args:
            ext_id: Kit が割り当てる拡張ID。
        """
        try:
            self._tool = JointJogTool()
            self._tool.install()
        except Exception:
            carb.log_error("[joint_jog] 起動に失敗\n" + traceback.format_exc())
            self._tool = None

    def on_shutdown(self) -> None:
        """拡張が無効化されたときに呼ばれる。"""
        if self._tool is not None:
            try:
                self._tool.uninstall()
            except Exception:
                carb.log_error("[joint_jog] 終了処理に失敗\n" + traceback.format_exc())
            self._tool = None
