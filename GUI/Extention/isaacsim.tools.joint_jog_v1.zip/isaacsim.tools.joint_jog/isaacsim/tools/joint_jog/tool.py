# SPDX-License-Identifier: Apache-2.0
"""ツール本体。モード管理・キー入力・ジョグ・設定ウィンドウ。"""

from __future__ import annotations

import math
import traceback

import carb
import carb.input
import carb.settings
import omni.appwindow
import omni.timeline
import omni.ui as ui
import omni.usd
from pxr import Usd, UsdGeom

from . import runtime
from .constants import (
    CONSUME_KEYS,
    DRIVE_LABELS,
    DRIVE_TELEPORT,
    EXT_ID,
    ICON_CHECKED_PATH,
    ICON_PATH,
    JOG_OP_TOKEN,
    ROT_LABELS,
    ROT_PRESETS_DEG,
    TRANS_LABELS,
    TRANS_PRESETS_MM,
    TRANSFORM_OP_SETTING,
    VIZ_DEBUG_DRAW,
    VIZ_DISPLAY_COLOR,
    VIZ_LABELS,
    VIZ_NONE,
    VIZ_OVERLAY,
    VIZ_SELECTION,
)
from .usd_helpers import (
    _is_prismatic,
    _is_revolute,
    _meters_per_unit,
    _read_joint_value,
    _stage,
    find_drive_joints,
    find_robots,
)
from .visualization import DebugDrawViz, DisplayColorViz, OverlayViz, SelectionViz


class JointJogTool:
    def __init__(self):
        self.mode_on = False
        self.viz_mode = VIZ_NONE
        self.drive_mode = DRIVE_TELEPORT

        self.trans_choice = 1  # 既定 10 mm
        self.trans_custom_mm = 5.0
        self.rot_choice = 1  # 既定 5°
        self.rot_custom_deg = 2.5

        self._robots: list[Usd.Prim] = []
        self._robot_idx = -1
        self._joints: list[Usd.Prim] = []
        self._joint_idx = -1

        self._chain_cache: dict[str, object] = {}
        self._articulation_cache: dict[str, tuple] = {}
        self._link_tree_cache: dict[str, object] = {}
        self._robot_span_cache: dict[str, float] = {}

        self._viz_display = DisplayColorViz()
        self._viz_selection = SelectionViz()
        self._viz_debug = DebugDrawViz()
        self._viz_overlay = OverlayViz()

        self._toolbar = None
        self._toolbar_button = None
        self._settings = carb.settings.get_settings()
        self._settings_sub = None
        self._prev_transform_op = None
        self._suppress_setting_cb = False

        self._input = None
        self._keyboard = None
        self._key_sub = None

        self._timeline_sub = None
        self._stage_sub = None

        self._window = None
        self._status_label = None
        self._robot_label = None
        self._joint_label = None
        self._value_label = None

    # -- 現在対象 ----------------------------------------------------------

    def current_robot(self) -> Usd.Prim | None:
        if 0 <= self._robot_idx < len(self._robots):
            prim = self._robots[self._robot_idx]
            if prim and prim.IsValid():
                return prim
        return None

    def current_joint(self) -> Usd.Prim | None:
        if 0 <= self._joint_idx < len(self._joints):
            prim = self._joints[self._joint_idx]
            if prim and prim.IsValid():
                return prim
        return None

    def robot_span(self) -> float:
        robot = self.current_robot()
        if robot is None:
            return 1.0
        key = str(robot.GetPath())
        if key not in self._robot_span_cache:
            cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render])
            try:
                span = cache.ComputeWorldBound(robot).ComputeAlignedRange().GetSize().GetLength()
            except Exception:
                span = 1.0
            self._robot_span_cache[key] = max(float(span), 1e-4)
        return self._robot_span_cache[key]

    # -- 巡回 --------------------------------------------------------------

    def cycle_robot(self, step: int):
        stage = _stage()
        if stage is None:
            return
        self._robots = find_robots(stage)
        if not self._robots:
            self._set_status("IsaacRobotAPI を持つプリムがステージにない")
            return
        if self._robot_idx < 0:
            self._robot_idx = 0 if step > 0 else len(self._robots) - 1
        else:
            self._robot_idx = (self._robot_idx + step) % len(self._robots)
        self._joints = []
        self._joint_idx = -1
        self._refresh_visualization()
        self._refresh_labels()

    def cycle_joint(self, step: int):
        stage = _stage()
        robot = self.current_robot()
        if stage is None:
            return
        if robot is None:
            self.cycle_robot(1)
            robot = self.current_robot()
            if robot is None:
                return
        if not self._joints:
            self._joints = find_drive_joints(stage, robot)
            self._joint_idx = -1
        if not self._joints:
            self._set_status("このロボットにドライブ付きジョイントがない")
            return
        if self._joint_idx < 0:
            self._joint_idx = 0 if step > 0 else len(self._joints) - 1
        else:
            self._joint_idx = (self._joint_idx + step) % len(self._joints)
        self._refresh_visualization()
        self._refresh_labels()

    # -- ステップ量 --------------------------------------------------------

    def step_for(self, joint_prim: Usd.Prim, stage: Usd.Stage) -> float:
        """1 ステップの変位を返す（回転はラジアン、直動はステージのリニアユニット）。"""
        if _is_revolute(joint_prim):
            if self.rot_choice < len(ROT_PRESETS_DEG):
                deg = ROT_PRESETS_DEG[self.rot_choice]
            else:
                deg = self.rot_custom_deg
            return math.radians(float(deg))
        if self.trans_choice < len(TRANS_PRESETS_MM):
            mm = TRANS_PRESETS_MM[self.trans_choice]
        else:
            mm = self.trans_custom_mm
        return (float(mm) / 1000.0) / _meters_per_unit(stage)

    # -- 駆動 --------------------------------------------------------------

    def _kinematic_chain(self, stage: Usd.Stage, robot: Usd.Prim):
        from isaacsim.robot.schema.kinematic_chain import KinematicChain

        key = str(robot.GetPath())
        chain = self._chain_cache.get(key)
        if chain is None:
            chain = KinematicChain(stage, robot)
            self._chain_cache[key] = chain
        return chain

    def _articulation(self, robot: Usd.Prim):
        from isaacsim.core.experimental.prims import Articulation

        key = str(robot.GetPath())
        cached = self._articulation_cache.get(key)
        if cached is not None:
            return cached
        art = Articulation(key)
        dof_paths = art.dof_paths[0]
        mapping = {str(p): i for i, p in enumerate(dof_paths)}
        self._articulation_cache[key] = (art, mapping)
        return self._articulation_cache[key]

    def jog(self, direction: int, multiplier: float = 1.0):
        stage = _stage()
        joint = self.current_joint()
        robot = self.current_robot()
        if stage is None or joint is None or robot is None:
            self._set_status("先に R でロボット、J でジョイントを選ぶ")
            return

        playing = omni.timeline.get_timeline_interface().is_playing()
        delta = self.step_for(joint, stage) * float(direction) * float(multiplier)
        joint_path = str(joint.GetPath())

        try:
            if not playing:
                # Play OFF: FK でボディのトランスフォームを書き換えるテレポート。
                # apply_joint_state が Play OFF 時に使うのと同じ経路だが、
                # KinematicChain を毎回作り直さずキャッシュしている。
                chain = self._kinematic_chain(stage, robot)
                current = _read_joint_value(joint)
                chain.teleport({joint_path: current + delta})
                mode_txt = "Play OFF / FK テレポート"
            else:
                art, mapping = self._articulation(robot)
                dof_index = mapping.get(joint_path)
                if dof_index is None:
                    self._set_status(f"DOF が見つからない: {joint_path}")
                    return
                # 単位系の食い違いを避けるため、書き込む API と同じ API から現在値を読む。
                if self.drive_mode == DRIVE_TELEPORT:
                    current = float(art.get_dof_positions(dof_indices=[dof_index]).numpy().reshape(-1)[0])
                else:
                    current = float(art.get_dof_position_targets(dof_indices=[dof_index]).numpy().reshape(-1)[0])
                # 物理テンサー API は回転がラジアン、直動がメートル。
                phys_delta = delta if _is_revolute(joint) else delta * _meters_per_unit(stage)
                target = current + phys_delta
                if self.drive_mode == DRIVE_TELEPORT:
                    art.set_dof_positions([[target]], dof_indices=[dof_index])
                    mode_txt = "Play ON / テレポート"
                else:
                    art.set_dof_position_targets([[target]], dof_indices=[dof_index])
                    mode_txt = "Play ON / ドライブ目標"
        except Exception:
            carb.log_error("[joint_jog] ジョグに失敗\n" + traceback.format_exc())
            self._set_status("ジョグに失敗（Console を確認）")
            return

        self._set_status(mode_txt)
        self._refresh_visualization()
        self._refresh_labels()

    # -- 可視化 ------------------------------------------------------------

    def _link_tree(self, stage: Usd.Stage, robot: Usd.Prim):
        from isaacsim.robot.schema import utils as rs_utils

        key = str(robot.GetPath())
        tree = self._link_tree_cache.get(key)
        if tree is None:
            tree = rs_utils.GenerateRobotLinkTree(stage, robot)
            self._link_tree_cache[key] = tree
        return tree

    def _links_of_current_joint(self):
        from isaacsim.robot.schema import utils as rs_utils

        stage = _stage()
        robot = self.current_robot()
        joint = self.current_joint()
        if stage is None or robot is None or joint is None:
            return [], []
        try:
            tree = self._link_tree(stage, robot)
            if tree is None:
                return [], []
            before, after = rs_utils.GetLinksFromJoint(tree, joint)
            return list(before or []), list(after or [])
        except Exception:
            carb.log_warn("[joint_jog] リンク特定に失敗\n" + traceback.format_exc())
            return [], []

    def _clear_all_viz(self):
        self._viz_display.clear()
        self._viz_debug.clear()
        self._viz_overlay.clear()
        # 選択ハイライトは、そのモードを使っていたときだけ消す。
        if self.viz_mode == VIZ_SELECTION:
            self._viz_selection.clear()

    def _refresh_visualization(self):
        if not self.mode_on or self.viz_mode == VIZ_NONE:
            self._clear_all_viz()
            return
        robot = self.current_robot()
        joint = self.current_joint()
        parent_links, child_links = self._links_of_current_joint()

        if self.viz_mode == VIZ_DISPLAY_COLOR:
            self._viz_debug.clear()
            self._viz_overlay.clear()
            self._viz_display.apply(robot, joint, parent_links, child_links)
        elif self.viz_mode == VIZ_SELECTION:
            self._viz_display.clear()
            self._viz_debug.clear()
            self._viz_overlay.clear()
            self._viz_selection.apply(robot, joint, parent_links, child_links)
        elif self.viz_mode == VIZ_DEBUG_DRAW:
            self._viz_display.clear()
            self._viz_overlay.clear()
            self._viz_debug.apply(robot, joint, parent_links, child_links)
        elif self.viz_mode == VIZ_OVERLAY:
            self._viz_display.clear()
            self._viz_debug.clear()
            self._viz_overlay.apply(robot, joint, parent_links, child_links)

    def set_viz_mode(self, mode: int):
        self._clear_all_viz()
        self.viz_mode = mode
        self._refresh_visualization()

    # -- モード切替 --------------------------------------------------------

    def set_mode(self, on: bool):
        if on == self.mode_on:
            return
        self.mode_on = on
        if on:
            self._prev_transform_op = self._settings.get(TRANSFORM_OP_SETTING)
            self._suppress_setting_cb = True
            self._settings.set(TRANSFORM_OP_SETTING, JOG_OP_TOKEN)
            self._suppress_setting_cb = False
            self._subscribe_keyboard()
            if self._window is not None:
                self._window.visible = True
            self._set_status("モード ON")
        else:
            self._unsubscribe_keyboard()
            self._clear_all_viz()
            if self._settings.get(TRANSFORM_OP_SETTING) == JOG_OP_TOKEN:
                self._suppress_setting_cb = True
                self._settings.set(TRANSFORM_OP_SETTING, self._prev_transform_op or "select")
                self._suppress_setting_cb = False
            self._set_status("モード OFF")
        self._sync_button(on)
        self._refresh_visualization()

    def _sync_button(self, on: bool):
        if self._toolbar is None:
            return
        try:
            widget = self._toolbar.get_widget(EXT_ID)
            if widget is not None and widget.model.get_value_as_bool() != on:
                widget.model.set_value(on)
        except Exception:
            pass

    def _on_transform_op_changed(self, *args):
        if self._suppress_setting_cb:
            return
        value = self._settings.get(TRANSFORM_OP_SETTING)
        if value != JOG_OP_TOKEN and self.mode_on:
            # 並進・回転・スケールのどれかが押された。こちらは降りる。
            self.set_mode(False)

    # -- キーボード --------------------------------------------------------

    def _subscribe_keyboard(self):
        if self._key_sub is not None:
            return
        self._input = carb.input.acquire_input_interface()
        self._keyboard = omni.appwindow.get_default_app_window().get_keyboard()
        self._key_sub = self._input.subscribe_to_keyboard_events(self._keyboard, self._on_key)

    def _unsubscribe_keyboard(self):
        if self._key_sub is None:
            return
        try:
            self._input.unsubscribe_to_keyboard_events(self._keyboard, self._key_sub)
        except Exception:
            pass
        self._key_sub = None

    def _on_key(self, event) -> bool:
        """モード ON の間だけ R / J / ↑ / ↓ を処理する。

        戻り値の意味（True が「消費」か「伝播」か）は carb.input の版によって
        解釈が変わりうるため、既定では NVIDIA のサンプル
        （isaacsim.robot.policy.examples）と同じく常に True を返す。
        サンプルはこの返し方で Kit の通常操作と共存できているので、
        ステージが操作不能になる事故を避けられる。

        自分のキーだけを他機能から奪いたい場合は CONSUME_KEYS を True にして、
        Viewport のカメラ操作とステージツリーが壊れないかを必ず確認すること。
        """
        if not self.mode_on:
            return True
        et = event.type
        if et not in (carb.input.KeyboardEventType.KEY_PRESS, carb.input.KeyboardEventType.KEY_REPEAT):
            return True

        key = event.input
        mods = event.modifiers
        shift = bool(mods & carb.input.KEYBOARD_MODIFIER_FLAG_SHIFT)
        ctrl = bool(mods & carb.input.KEYBOARD_MODIFIER_FLAG_CONTROL)
        alt = bool(mods & carb.input.KEYBOARD_MODIFIER_FLAG_ALT)
        if ctrl or alt:
            return True

        K = carb.input.KeyboardInput
        handled = False
        try:
            if key == K.R:
                self.cycle_robot(-1 if shift else 1)
                handled = True
            elif key == K.J:
                self.cycle_joint(-1 if shift else 1)
                handled = True
            elif key == K.UP:
                self.jog(+1, 10.0 if shift else 1.0)
                handled = True
            elif key == K.DOWN:
                self.jog(-1, 10.0 if shift else 1.0)
                handled = True
        except Exception:
            carb.log_error("[joint_jog] キー処理で例外\n" + traceback.format_exc())

        if handled and CONSUME_KEYS:
            return False
        return True

    # -- タイムライン／ステージ -------------------------------------------

    def _on_timeline(self, event):
        et = omni.timeline.TimelineEventType(event.type)
        if et in (omni.timeline.TimelineEventType.PLAY, omni.timeline.TimelineEventType.STOP):
            # Play の開始・停止でテンサーエンティティが張り替わるのでキャッシュを捨てる。
            self._articulation_cache.clear()
            self._refresh_labels()

    def _on_stage(self, event):
        if event.type == int(omni.usd.StageEventType.OPENED) or event.type == int(omni.usd.StageEventType.CLOSING):
            self._robots = []
            self._robot_idx = -1
            self._joints = []
            self._joint_idx = -1
            self._chain_cache.clear()
            self._articulation_cache.clear()
            self._link_tree_cache.clear()
            self._robot_span_cache.clear()
            self._clear_all_viz()
            self._refresh_labels()

    # -- UI ----------------------------------------------------------------

    def _set_status(self, text: str):
        if self._status_label is not None:
            self._status_label.text = text

    def _refresh_labels(self):
        robot = self.current_robot()
        joint = self.current_joint()
        if self._robot_label is not None:
            if robot is None:
                self._robot_label.text = "ロボット: （未選択）"
            else:
                self._robot_label.text = f"ロボット: {robot.GetName()}  [{self._robot_idx + 1}/{len(self._robots)}]  {robot.GetPath()}"
        if self._joint_label is not None:
            if joint is None:
                self._joint_label.text = "ジョイント: （未選択）"
            else:
                kind = "回転" if _is_revolute(joint) else ("直動" if _is_prismatic(joint) else "?")
                self._joint_label.text = (
                    f"ジョイント: {joint.GetName()}  [{self._joint_idx + 1}/{len(self._joints)}]  ({kind})"
                )
        if self._value_label is not None:
            stage = _stage()
            if joint is None or stage is None:
                self._value_label.text = "現在値: -"
            elif _is_revolute(joint):
                self._value_label.text = f"現在値: {math.degrees(_read_joint_value(joint)):.3f} °"
            else:
                mm = _read_joint_value(joint) * _meters_per_unit(stage) * 1000.0
                self._value_label.text = f"現在値: {mm:.3f} mm"

    def _build_window(self):
        self._window = ui.Window("Joint Jog", width=460, height=420)
        with self._window.frame:
            with ui.VStack(spacing=8, height=0):
                ui.Spacer(height=4)

                self._status_label = ui.Label("モード OFF", style={"color": 0xFF88CCFF})
                self._robot_label = ui.Label("ロボット: （未選択）", word_wrap=True)
                self._joint_label = ui.Label("ジョイント: （未選択）", word_wrap=True)
                self._value_label = ui.Label("現在値: -")

                ui.Separator(height=6)

                with ui.HStack(height=26, spacing=6):
                    ui.Button("← ロボット", clicked_fn=lambda: self.cycle_robot(-1))
                    ui.Button("ロボット →", clicked_fn=lambda: self.cycle_robot(1))
                    ui.Button("← ジョイント", clicked_fn=lambda: self.cycle_joint(-1))
                    ui.Button("ジョイント →", clicked_fn=lambda: self.cycle_joint(1))

                with ui.HStack(height=26, spacing=6):
                    ui.Button("－", clicked_fn=lambda: self.jog(-1))
                    ui.Button("＋", clicked_fn=lambda: self.jog(+1))

                ui.Separator(height=6)

                with ui.HStack(height=26, spacing=6):
                    ui.Label("直動ステップ", width=110)
                    trans_combo = ui.ComboBox(self.trans_choice, *TRANS_LABELS)
                    ui.Label("カスタム[mm]", width=90)
                    trans_field = ui.FloatField(width=70)
                    trans_field.model.set_value(self.trans_custom_mm)

                with ui.HStack(height=26, spacing=6):
                    ui.Label("回転ステップ", width=110)
                    rot_combo = ui.ComboBox(self.rot_choice, *ROT_LABELS)
                    ui.Label("カスタム[°]", width=90)
                    rot_field = ui.FloatField(width=70)
                    rot_field.model.set_value(self.rot_custom_deg)

                with ui.HStack(height=26, spacing=6):
                    ui.Label("駆動方式", width=110)
                    drive_combo = ui.ComboBox(self.drive_mode, *DRIVE_LABELS)

                with ui.HStack(height=26, spacing=6):
                    ui.Label("可視化", width=110)
                    viz_combo = ui.ComboBox(self.viz_mode, *VIZ_LABELS)

                ui.Separator(height=6)
                ui.Label(
                    "R: 次のロボット / Shift+R: 前　J: 次のジョイント / Shift+J: 前\n"
                    "↑ ↓: ジョグ　Shift+↑↓: ステップ×10\n"
                    "Play OFF は FK テレポート固定（駆動方式の指定は Play ON でのみ効く）",
                    word_wrap=True,
                    style={"color": 0xFFAAAAAA},
                )

        def on_trans(model, _=None):
            self.trans_choice = model.get_item_value_model().get_value_as_int()

        def on_rot(model, _=None):
            self.rot_choice = model.get_item_value_model().get_value_as_int()

        def on_drive(model, _=None):
            self.drive_mode = model.get_item_value_model().get_value_as_int()

        def on_viz(model, _=None):
            self.set_viz_mode(model.get_item_value_model().get_value_as_int())

        def on_trans_custom(model):
            self.trans_custom_mm = float(model.get_value_as_float())

        def on_rot_custom(model):
            self.rot_custom_deg = float(model.get_value_as_float())

        self._subs = [
            trans_combo.model.subscribe_item_changed_fn(on_trans),
            rot_combo.model.subscribe_item_changed_fn(on_rot),
            drive_combo.model.subscribe_item_changed_fn(on_drive),
            viz_combo.model.subscribe_item_changed_fn(on_viz),
            trans_field.model.subscribe_value_changed_fn(on_trans_custom),
            rot_field.model.subscribe_value_changed_fn(on_rot_custom),
        ]

    # -- インストール／アンインストール -----------------------------------

    def install(self):
        from omni.kit.widget.toolbar import SimpleToolButton, get_instance

        runtime.set_tool(self)

        self._toolbar = get_instance()
        self._toolbar_button = SimpleToolButton(
            name=EXT_ID,
            tooltip="Joint Jog: 関節角をキーで直接動かす",
            icon_path=ICON_PATH,
            icon_checked_path=ICON_CHECKED_PATH,
            toggled_fn=lambda checked: self.set_mode(bool(checked)),
        )
        self._toolbar.add_widget(widget_group=self._toolbar_button, priority=500)

        self._settings_sub = self._settings.subscribe_to_node_change_events(
            TRANSFORM_OP_SETTING, self._on_transform_op_changed
        )

        self._timeline_sub = (
            omni.timeline.get_timeline_interface()
            .get_timeline_event_stream()
            .create_subscription_to_pop(self._on_timeline, name="joint_jog_timeline")
        )
        self._stage_sub = (
            omni.usd.get_context()
            .get_stage_event_stream()
            .create_subscription_to_pop(self._on_stage, name="joint_jog_stage")
        )

        self._viz_overlay.install()
        self._build_window()
        self._refresh_labels()
        carb.log_info("[joint_jog] インストール完了")

    def uninstall(self):
        self.set_mode(False)
        self._clear_all_viz()
        self._viz_overlay.uninstall()

        if self._toolbar is not None and self._toolbar_button is not None:
            try:
                self._toolbar.remove_widget(self._toolbar_button)
                self._toolbar_button.clean()
            except Exception:
                pass
        self._toolbar_button = None
        self._toolbar = None

        if self._settings_sub is not None:
            try:
                self._settings.unsubscribe_to_change_events(self._settings_sub)
            except Exception:
                pass
            self._settings_sub = None

        self._timeline_sub = None
        self._stage_sub = None

        if self._window is not None:
            self._window.visible = False
            self._window.destroy()
            self._window = None

        if runtime.get_tool() is self:
            runtime.set_tool(None)
        carb.log_info("[joint_jog] アンインストール完了")
