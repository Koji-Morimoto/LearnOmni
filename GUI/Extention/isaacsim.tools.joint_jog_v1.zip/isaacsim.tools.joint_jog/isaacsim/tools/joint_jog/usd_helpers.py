# SPDX-License-Identifier: Apache-2.0
"""USD 読み取りヘルパと、ロボット／ジョイントの探索。"""

from __future__ import annotations

import math

from pxr import Gf, Usd, UsdGeom, UsdPhysics

import omni.usd


def _stage() -> Usd.Stage | None:
    return omni.usd.get_context().get_stage()


def _meters_per_unit(stage: Usd.Stage) -> float:
    """ステージの 1 ユニットが何メートルかを返す。"""
    try:
        return float(UsdGeom.GetStageMetersPerUnit(stage))
    except Exception:
        return 1.0


def _world_matrix(prim: Usd.Prim) -> Gf.Matrix4d:
    return UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default())


def _is_revolute(prim: Usd.Prim) -> bool:
    return bool(prim.IsA(UsdPhysics.RevoluteJoint))


def _is_prismatic(prim: Usd.Prim) -> bool:
    return bool(prim.IsA(UsdPhysics.PrismaticJoint))


def _drive_instances(prim: Usd.Prim) -> list[str]:
    """このジョイントに適用されている PhysicsDriveAPI のインスタンス名を返す。

    多重適用スキーマなので、適用済みスキーマ名は "PhysicsDriveAPI:angular" の形で入る。
    """
    out = []
    for schema in prim.GetAppliedSchemas():
        if schema.startswith("PhysicsDriveAPI:"):
            out.append(schema.split(":", 1)[1])
    return out


def _has_drive(prim: Usd.Prim) -> bool:
    if _drive_instances(prim):
        return True
    # 適用済みスキーマ一覧に出ない書かれ方をしている資産への保険として、
    # ドライブ属性そのものの有無も見る。
    for name in ("drive:angular:physics:targetPosition", "drive:linear:physics:targetPosition"):
        if prim.GetAttribute(name):
            return True
    return False


def _joint_axis(prim: Usd.Prim) -> Gf.Vec3d:
    """ジョイントのローカル軸ベクトルを返す。"""
    axis = "X"
    if _is_revolute(prim):
        axis = str(UsdPhysics.RevoluteJoint(prim).GetAxisAttr().Get() or "X")
    elif _is_prismatic(prim):
        axis = str(UsdPhysics.PrismaticJoint(prim).GetAxisAttr().Get() or "X")
    return {"X": Gf.Vec3d(1, 0, 0), "Y": Gf.Vec3d(0, 1, 0), "Z": Gf.Vec3d(0, 0, 1)}.get(axis, Gf.Vec3d(1, 0, 0))


def _read_joint_value(prim: Usd.Prim) -> float:
    """USD 上のジョイント状態を読む。

    Returns:
        回転ジョイントはラジアン、直動ジョイントはステージのリニアユニット。
    """
    if _is_revolute(prim):
        attr = prim.GetAttribute("state:angular:physics:position")
        if attr and attr.Get() is not None:
            return math.radians(float(attr.Get()))
        attr = prim.GetAttribute("drive:angular:physics:targetPosition")
        if attr and attr.Get() is not None:
            return math.radians(float(attr.Get()))
    elif _is_prismatic(prim):
        attr = prim.GetAttribute("state:linear:physics:position")
        if attr and attr.Get() is not None:
            return float(attr.Get())
        attr = prim.GetAttribute("drive:linear:physics:targetPosition")
        if attr and attr.Get() is not None:
            return float(attr.Get())
    return 0.0


def _joint_world_matrix(robot_prim: Usd.Prim, joint_prim: Usd.Prim) -> Gf.Matrix4d | None:
    """ジョイントフレームのワールド変換を返す。"""
    from isaacsim.robot.schema import utils as rs_utils

    local = rs_utils.GetJointPose(robot_prim, joint_prim)
    if local is None:
        return None
    return Gf.Matrix4d(local) * _world_matrix(robot_prim)


# ---------------------------------------------------------------------------
# ロボット／ジョイントの探索
# ---------------------------------------------------------------------------


def find_robots(stage: Usd.Stage) -> list[Usd.Prim]:
    """IsaacRobotAPI が適用されたプリムをステージ順に集める。"""
    from isaacsim.robot.schema import Classes

    token = Classes.ROBOT_API.value
    out = []
    for prim in stage.Traverse():
        try:
            if prim.HasAPI(token):
                out.append(prim)
        except Exception:
            continue
    return out


def find_drive_joints(stage: Usd.Stage, robot_prim: Usd.Prim) -> list[Usd.Prim]:
    """ロボット配下のジョイントのうちドライブを持つものを返す。"""
    from isaacsim.robot.schema import utils as rs_utils

    joints = rs_utils.GetAllRobotJoints(stage, robot_prim)
    out = []
    for j in joints:
        if not j or not j.IsValid():
            continue
        if not (_is_revolute(j) or _is_prismatic(j)):
            continue
        if _has_drive(j):
            out.append(j)
    return out
