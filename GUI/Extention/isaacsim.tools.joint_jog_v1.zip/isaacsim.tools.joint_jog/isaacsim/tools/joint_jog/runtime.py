# SPDX-License-Identifier: Apache-2.0
"""現在有効な JointJogTool インスタンスへの参照を保持するモジュール。

ビューポートオーバーレイのマニピュレータは Kit 側から生成されるため、
ツール本体を引数で渡せない。その一点のためだけの参照置き場。"""

from __future__ import annotations

_tool = None


def set_tool(tool) -> None:
    """現在有効なツールを登録する。None を渡すと登録を解除する。"""
    global _tool
    _tool = tool


def get_tool():
    """現在有効なツールを返す。未登録なら None。"""
    return _tool
