# SPDX-License-Identifier: Apache-2.0
"""Joint Jog 拡張の定数定義。"""

from __future__ import annotations

from pxr import Gf

EXT_ID = "isaac_joint_jog"

# ツールバーのアイコン。${glyphs} は Kit 標準グリフの検索パス。
# 手元の Kit に別のグリフを使いたければここだけ差し替える。
ICON_PATH = "${glyphs}/lock_open.svg"
ICON_CHECKED_PATH = "${glyphs}/lock.svg"

# /app/transform/operation に書き込む独自トークン。
# 組み込みの Select / Move / Rotate / Scale はこの設定に連動するラジオ動作なので、
# 未知のトークンを入れることで 4 つとも OFF になることを狙っている。
TRANSFORM_OP_SETTING = "/app/transform/operation"
JOG_OP_TOKEN = "isaac_joint_jog"

# キーイベントを他の機能から奪うかどうか。
# 既定は False（奪わない）。詳しい理由は JointJogTool._on_key のコメントを参照。
CONSUME_KEYS = False

# 可視化モード
VIZ_NONE = 0
VIZ_DISPLAY_COLOR = 1
VIZ_SELECTION = 2
VIZ_DEBUG_DRAW = 3
VIZ_OVERLAY = 4
VIZ_LABELS = [
    "なし",
    "displayColor 上書き（セッションレイヤ）",
    "選択ハイライト流用",
    "debug_draw（バウンディングボックス＋軸）",
    "ビューポートオーバーレイ（omni.ui.scene）",
]

# 駆動方式
DRIVE_TELEPORT = 0
DRIVE_MOTOR = 1
DRIVE_LABELS = ["テレポート", "モーター（ドライブ目標）"]

# ステップのプリセット
TRANS_PRESETS_MM = [1.0, 10.0, 100.0]
TRANS_LABELS = ["1 mm", "10 mm", "100 mm", "カスタム"]
ROT_PRESETS_DEG = [1.0, 5.0, 10.0, 30.0, 90.0]
ROT_LABELS = ["1°", "5°", "10°", "30°", "90°", "カスタム"]

# 色（RGB, 0-1）
COLOR_ROBOT = Gf.Vec3f(0.25, 0.45, 0.85)
COLOR_LINK_PARENT = Gf.Vec3f(0.95, 0.75, 0.15)
COLOR_LINK_CHILD = Gf.Vec3f(0.95, 0.25, 0.25)

# debug_draw / オーバーレイ用（RGBA, 0-1）
RGBA_ROBOT_BBOX = (0.25, 0.45, 0.85, 0.9)
RGBA_LINK_PARENT = (0.95, 0.75, 0.15, 1.0)
RGBA_LINK_CHILD = (0.95, 0.25, 0.25, 1.0)
RGBA_AXIS = (0.1, 1.0, 0.4, 1.0)
