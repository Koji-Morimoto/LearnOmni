# SPDX-License-Identifier: Apache-2.0
"""4 種類の可視化手法の実装。"""

from __future__ import annotations

import traceback

import carb
import omni.kit.app
import omni.usd
from omni.ui import scene as sc
from pxr import Gf, Sdf, Usd, UsdGeom

from . import runtime
from .constants import (
    COLOR_LINK_CHILD,
    COLOR_LINK_PARENT,
    COLOR_ROBOT,
    EXT_ID,
    RGBA_AXIS,
    RGBA_LINK_CHILD,
    RGBA_LINK_PARENT,
    RGBA_ROBOT_BBOX,
    VIZ_OVERLAY,
)
from .usd_helpers import _joint_axis, _joint_world_matrix, _stage


class DisplayColorViz:
    """セッションレイヤ上で primvars:displayColor を上書きする可視化。

    元のレイヤは一切書き換えない。解除時はセッションレイヤに作った
    プリムスペックを削除して元の見た目に戻す。
    """

    def __init__(self):
        self._touched: set[str] = set()

    def clear(self):
        stage = _stage()
        if stage is None or not self._touched:
            self._touched.clear()
            return
        session = stage.GetSessionLayer()
        with Sdf.ChangeBlock():
            for path in list(self._touched):
                spec = session.GetPrimAtPath(Sdf.Path(path))
                if spec is not None:
                    attr = spec.properties.get("primvars:displayColor")
                    if attr is not None:
                        spec.RemoveProperty(attr)
        self._touched.clear()

    def _paint(self, stage: Usd.Stage, root: Usd.Prim, color: Gf.Vec3f):
        for prim in Usd.PrimRange(root):
            gprim = UsdGeom.Gprim(prim)
            if not gprim:
                continue
            attr = gprim.CreateDisplayColorAttr()
            attr.Set([color])
            self._touched.add(str(prim.GetPath()))

    def apply(self, robot_prim, joint_prim, parent_links, child_links):
        stage = _stage()
        if stage is None or robot_prim is None:
            return
        self.clear()
        with Usd.EditContext(stage, stage.GetSessionLayer()):
            with Sdf.ChangeBlock():
                self._paint(stage, robot_prim, COLOR_ROBOT)
                for link in parent_links:
                    self._paint(stage, link, COLOR_LINK_PARENT)
                for link in child_links:
                    self._paint(stage, link, COLOR_LINK_CHILD)


# ---------------------------------------------------------------------------
# 可視化：選択ハイライト流用
# ---------------------------------------------------------------------------


class SelectionViz:
    """omni.usd の選択機構をそのまま流用する可視化。

    実装は最小で済むが、選択には他機能が連動する（プロパティウィンドウ、
    変換マニピュレータ、ステージツリーのスクロール等）ので副作用が大きい。
    比較評価用として用意している。
    """

    def clear(self):
        try:
            omni.usd.get_context().get_selection().clear_selected_prim_paths()
        except Exception:
            pass

    def apply(self, robot_prim, joint_prim, parent_links, child_links):
        paths = [str(p.GetPath()) for p in list(parent_links) + list(child_links)]
        if joint_prim is not None:
            paths.append(str(joint_prim.GetPath()))
        if not paths:
            self.clear()
            return
        try:
            omni.usd.get_context().get_selection().set_selected_prim_paths(paths, False)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# 可視化：debug_draw
# ---------------------------------------------------------------------------


def _bbox_lines(prim: Usd.Prim, cache: UsdGeom.BBoxCache) -> tuple[list, list]:
    """プリムのワールドバウンディングボックスをワイヤーフレームの線分に展開する。"""
    try:
        box = cache.ComputeWorldBound(prim)
    except Exception:
        return [], []
    rng = box.ComputeAlignedRange()
    if rng.IsEmpty():
        return [], []
    mn, mx = rng.GetMin(), rng.GetMax()
    c = [
        Gf.Vec3d(mn[0], mn[1], mn[2]),
        Gf.Vec3d(mx[0], mn[1], mn[2]),
        Gf.Vec3d(mx[0], mx[1], mn[2]),
        Gf.Vec3d(mn[0], mx[1], mn[2]),
        Gf.Vec3d(mn[0], mn[1], mx[2]),
        Gf.Vec3d(mx[0], mn[1], mx[2]),
        Gf.Vec3d(mx[0], mx[1], mx[2]),
        Gf.Vec3d(mn[0], mx[1], mx[2]),
    ]
    edges = [(0, 1), (1, 2), (2, 3), (3, 0), (4, 5), (5, 6), (6, 7), (7, 4), (0, 4), (1, 5), (2, 6), (3, 7)]
    starts = [tuple(c[a]) for a, _ in edges]
    ends = [tuple(c[b]) for _, b in edges]
    return starts, ends


class DebugDrawViz:
    """isaacsim.util.debug_draw で線を引く可視化。

    USD には一切書き込まないので、ステージの差分やアンドゥ履歴を汚さない。
    """

    def __init__(self):
        self._iface = None

    def _get(self):
        if self._iface is None:
            try:
                mgr = omni.kit.app.get_app().get_extension_manager()
                if not mgr.is_extension_enabled("isaacsim.util.debug_draw"):
                    mgr.set_extension_enabled_immediate("isaacsim.util.debug_draw", True)
                from isaacsim.util.debug_draw import _debug_draw

                self._iface = _debug_draw.acquire_debug_draw_interface()
            except Exception:
                carb.log_warn("[joint_jog] isaacsim.util.debug_draw を有効化できなかった")
                self._iface = None
        return self._iface

    def clear(self):
        iface = self._get()
        if iface is not None:
            try:
                iface.clear_lines()
            except Exception:
                pass

    def apply(self, robot_prim, joint_prim, parent_links, child_links):
        iface = self._get()
        stage = _stage()
        if iface is None or stage is None or robot_prim is None:
            return
        iface.clear_lines()
        cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_, UsdGeom.Tokens.render])

        starts, ends, colors, widths = [], [], [], []

        def add(prim, rgba, width):
            s, e = _bbox_lines(prim, cache)
            starts.extend(s)
            ends.extend(e)
            colors.extend([rgba] * len(s))
            widths.extend([width] * len(s))

        add(robot_prim, RGBA_ROBOT_BBOX, 1.0)
        for link in parent_links:
            add(link, RGBA_LINK_PARENT, 2.0)
        for link in child_links:
            add(link, RGBA_LINK_CHILD, 2.0)

        # ジョイント軸
        if joint_prim is not None:
            mat = _joint_world_matrix(robot_prim, joint_prim)
            if mat is not None:
                origin = mat.Transform(Gf.Vec3d(0, 0, 0))
                axis = mat.TransformDir(_joint_axis(joint_prim)).GetNormalized()
                try:
                    span = cache.ComputeWorldBound(robot_prim).ComputeAlignedRange().GetSize().GetLength()
                except Exception:
                    span = 1.0
                half = max(span * 0.15, 1e-4)
                starts.append(tuple(origin - axis * half))
                ends.append(tuple(origin + axis * half))
                colors.append(RGBA_AXIS)
                widths.append(4.0)

        if starts:
            try:
                iface.draw_lines(starts, ends, colors, widths)
            except Exception:
                carb.log_warn("[joint_jog] draw_lines に失敗\n" + traceback.format_exc())


# ---------------------------------------------------------------------------
# 可視化：ビューポートオーバーレイ（omni.ui.scene）
# ---------------------------------------------------------------------------


class _OverlayManipulator(sc.Manipulator):
    """ロボットスキーマUIのジョイントアイコンと同じ描き方のマーカー。

    画面に正対する円（sc.Arc + look_at=CAMERA + scale_to=NDC）で、
    isaacsim.robot.schema.ui のジョイント接続表示と同じ見え方になる。
    """

    def on_build(self):
        tool = runtime.get_tool()
        if tool is None or tool.viz_mode != VIZ_OVERLAY or not tool.mode_on:
            return
        joint = tool.current_joint()
        robot = tool.current_robot()
        if joint is None or robot is None:
            return
        mat = _joint_world_matrix(robot, joint)
        if mat is None:
            return
        origin = mat.Transform(Gf.Vec3d(0, 0, 0))
        axis = mat.TransformDir(_joint_axis(joint)).GetNormalized()
        half = max(tool.robot_span() * 0.15, 1e-4)

        p0 = origin - axis * half
        p1 = origin + axis * half
        sc.Line([p0[0], p0[1], p0[2]], [p1[0], p1[1], p1[2]], color=RGBA_AXIS, thickness=3)

        with sc.Transform(transform=sc.Matrix44.get_translation_matrix(origin[0], origin[1], origin[2])):
            with sc.Transform(look_at=sc.Transform.LookAt.CAMERA, scale_to=sc.Space.NDC):
                sc.Arc(0.022, tesselation=32, color=RGBA_AXIS, wireframe=True, thickness=3)
                sc.Arc(0.010, tesselation=32, color=RGBA_LINK_CHILD, wireframe=False)


class _OverlayScene:
    """omni.kit.viewport.registry から各ビューポートごとに生成されるシーン。"""

    _instances: list = []

    def __init__(self, *args, **kwargs):
        self.visible = True
        self._manipulator = _OverlayManipulator()
        _OverlayScene._instances.append(self)

    def invalidate(self):
        if self._manipulator is not None:
            self._manipulator.invalidate()

    def destroy(self):
        if self in _OverlayScene._instances:
            _OverlayScene._instances.remove(self)
        self._manipulator = None


class OverlayViz:
    """ビューポートに omni.ui.scene のオーバーレイを登録する可視化。"""

    def __init__(self):
        self._registration = None

    def install(self):
        if self._registration is not None:
            return
        try:
            from omni.kit.viewport.registry import RegisterScene

            self._registration = RegisterScene(_OverlayScene, EXT_ID)
        except Exception:
            carb.log_warn("[joint_jog] ビューポートオーバーレイの登録に失敗\n" + traceback.format_exc())

    def uninstall(self):
        self._registration = None
        _OverlayScene._instances.clear()

    def clear(self):
        for inst in list(_OverlayScene._instances):
            inst.invalidate()

    def apply(self, robot_prim, joint_prim, parent_links, child_links):
        for inst in list(_OverlayScene._instances):
            inst.invalidate()
